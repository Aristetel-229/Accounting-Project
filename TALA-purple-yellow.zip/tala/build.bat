@echo off
rem Compiles TALA into the "out" folder (needs a JDK 17 or newer)
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out
dir /s /b src\main\java\*.java > sources.txt
javac -encoding UTF-8 -d out @sources.txt
if errorlevel 1 (
  del sources.txt
  echo Build failed.
  exit /b 1
)
del sources.txt
echo Built into the "out" folder.
