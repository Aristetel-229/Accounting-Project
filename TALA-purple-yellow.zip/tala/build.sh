#!/usr/bin/env bash
# Compiles TALA into ./out  (needs a JDK 17 or newer)
set -e
cd "$(dirname "$0")"
rm -rf out
mkdir out
javac -encoding UTF-8 -d out $(find src/main -name '*.java')
echo "Built into ./out"
