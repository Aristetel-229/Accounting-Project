#!/usr/bin/env bash
# Runs the self-checking accounting tests (no MySQL and no display needed).
set -e
cd "$(dirname "$0")"
./build.sh
rm -rf test-out
mkdir test-out
javac -encoding UTF-8 -cp out -d test-out src/test/java/tala/AccountingCheck.java
java -ea -cp out:test-out tala.AccountingCheck
