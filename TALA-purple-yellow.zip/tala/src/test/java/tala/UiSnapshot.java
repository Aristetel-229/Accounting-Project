package tala;

import tala.ui.*;
import tala.logic.*;
import tala.data.*;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/*
 * ==============================================================
 *  UiSnapshot.java   [Tests]
 *  WHAT THIS FILE DOES: Opens every screen with sample data and saves a picture of each one.
 *  USED BY: nobody (run by hand)
 * ==============================================================
 */

/**
 * Drives the real UI against the in-memory store and saves a PNG of every screen.
 * Needs a display (on a server: xvfb-run -a java -cp out:test-out tala.UiSnapshot /some/dir).
 */
public class UiSnapshot {

    private static int failures = 0;

    private static void check(String what, boolean ok) {
        System.out.println((ok ? "  ok    " : "  FAIL  ") + what);
        if (!ok) {
            failures++;
        }
    }

    private static <T extends Component> List<T> find(Container root, Class<T> type) {
        List<T> out = new ArrayList<>();
        for (Component c : root.getComponents()) {
            if (type.isInstance(c)) {
                out.add(type.cast(c));
            }
            if (c instanceof Container k) {
                out.addAll(find(k, type));
            }
        }
        return out;
    }

    private static void ui(Runnable r) throws Exception {
        SwingUtilities.invokeAndWait(r);
        Thread.sleep(250);
        SwingUtilities.invokeAndWait(() -> { });
    }

    private static void snap(MainFrame frame, File dir, String name) throws Exception {
        ui(() -> { });
        BufferedImage img = new BufferedImage(frame.getContentPane().getWidth(), frame.getContentPane().getHeight(),
                BufferedImage.TYPE_INT_RGB);
        SwingUtilities.invokeAndWait(() -> {
            Graphics2D g = img.createGraphics();
            frame.getContentPane().paintAll(g);
            g.dispose();
        });
        ImageIO.write(img, "png", new File(dir, name + ".png"));
    }

    public static void main(String[] args) throws Exception {
        File dir = new File(args.length > 0 ? args[0] : ".");
        dir.mkdirs();
        Repo.use(MemoryStore.withSampleData());
        Status.setDemo(true);

        final MainFrame[] holder = new MainFrame[1];
        SwingUtilities.invokeAndWait(() -> {
            holder[0] = new MainFrame();
            holder[0].setVisible(true);
        });
        MainFrame frame = holder[0];

        String[][] pages = {
                {MainFrame.DASHBOARD, "1-dashboard"}, {MainFrame.JOURNAL_ENTRY, "2-journal-entry"},
                {MainFrame.GENERAL_JOURNAL, "3-general-journal"}, {MainFrame.CHART, "4-chart-of-accounts"},
                {MainFrame.LEDGER, "5-general-ledger"}, {MainFrame.WORKSHEET, "6-12-columnar"}};
        for (String[] p : pages) {
            ui(() -> frame.showPage(p[0]));
            snap(frame, dir, p[1]);
            System.out.println("  saved " + p[1] + ".png");
        }

        System.out.println("Driving the Journal Entry form:");
        ui(() -> frame.showPage(MainFrame.JOURNAL_ENTRY));
        List<Theme.HintField> fields = find(frame, Theme.HintField.class);
        // order of creation in EntryForm: date, reference, amount, description
        Theme.HintField amount = fields.get(2), desc = fields.get(3);
        @SuppressWarnings("unchecked")
        List<JComboBox<Account>> combos = (List<JComboBox<Account>>) (List<?>) find(frame, JComboBox.class);
        JComboBox<Account> debit = combos.get(0), credit = combos.get(1);
        JButton post = find(frame, Theme.Btn.class).stream().filter(b -> b.getText().startsWith("Validate")).findFirst().orElseThrow();
        JButton delete = find(frame, Theme.Btn.class).stream().filter(b -> b.getText().startsWith("Delete")).findFirst().orElseThrow();
        int before = Repo.entries().size();

        // 1. empty amount must be refused
        ui(post::doClick);
        check("posting with no amount is refused", Repo.entries().size() == before);
        snap(frame, dir, "7-journal-entry-error");

        // 2. same account on both sides must be refused
        ui(() -> {
            amount.setText("1,250.50");
            desc.setText("Test sale");
            debit.setSelectedIndex(0);
            credit.setSelectedIndex(0);
        });
        ui(post::doClick);
        check("same debit and credit account is refused", Repo.entries().size() == before);

        // 3. a valid entry is posted
        ui(() -> credit.setSelectedIndex(findIndex(credit, 4010)));
        ui(post::doClick);
        check("valid entry is posted", Repo.entries().size() == before + 1);
        Entry last = Repo.entries().stream().filter(e -> e.description().equals("Test sale")).findFirst().orElseThrow();
        check("amount stored as 1250.50", last.amount().toPlainString().equals("1250.50"));
        check("debit Cash / credit Service Revenue", last.debitCode() == 1010 && last.creditCode() == 4010);
        check("form cleared after posting", amount.getText().isEmpty() && desc.getText().isEmpty());
        snap(frame, dir, "8-journal-entry-posted");

        // 4. delete the selected entry
        JTable table = find(frame, JTable.class).stream().filter(t -> t.getColumnCount() == 6).findFirst().orElseThrow();
        int row = -1;
        for (int i = 0; i < table.getRowCount(); i++) {
            if ("Test sale".equals(table.getValueAt(i, 2))) {
                row = i;
            }
        }
        check("posted entry appears in the table", row >= 0);
        System.out.println("  (delete asks for confirmation in a dialog; checking the repository path directly)");
        Repo.delete(last.id());
        check("delete removes just that entry", Repo.entries().size() == before);

        // 5. every page still renders after the changes, and the books still balance
        for (String[] p : pages) {
            ui(() -> frame.showPage(p[0]));
        }
        Accounting.Totals t = Accounting.totals(Repo.accounts(), Repo.entries());
        check("accounting equation balanced", t.balanced());
        List<JLabel> labels = find(frame, JLabel.class);
        check("dashboard shows the balanced message",
                labels.stream().anyMatch(l -> l.getText() != null && l.getText().startsWith("Accounting equation balanced")));

        // 6. the case from the original screens: Dr Cash / Cr Accounts Receivable leaves receivables with a credit balance
        Repo.insert(new Entry(0, java.time.LocalDate.of(2026, 11, 3), "JE000777", "utang", 1010, 1100,
                new java.math.BigDecimal("1000.00"), false));
        ui(() -> frame.showPage(MainFrame.LEDGER));
        snap(frame, dir, "9-ledger-abnormal");

        System.out.println(failures == 0 ? "\nUI checks passed." : "\n" + failures + " UI check(s) FAILED.");
        System.exit(failures == 0 ? 0 : 1);
    }

    private static int findIndex(JComboBox<Account> box, int code) {
        for (int i = 0; i < box.getItemCount(); i++) {
            if (box.getItemAt(i).code() == code) {
                return i;
            }
        }
        throw new IllegalStateException("account " + code + " not in list");
    }
}
