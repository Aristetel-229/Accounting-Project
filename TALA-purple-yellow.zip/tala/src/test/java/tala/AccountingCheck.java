package tala;

import tala.logic.*;
import tala.data.*;

import java.math.BigDecimal;
import java.util.List;

/*
 * ==============================================================
 *  AccountingCheck.java   [Tests]
 *  WHAT THIS FILE DOES: Automatic checks for the accounting math. Run ./test.sh and look for "All checks passed."
 *  USED BY: nobody (run by test.sh)
 * ==============================================================
 */

/**
 * Plain self-checking test (no JUnit needed). Run with:  java -ea -cp out:test-out tala.AccountingCheck
 * Exits with a non-zero status when something is wrong.
 */
public class AccountingCheck {

    private static int failures = 0;

    private static void check(String what, boolean ok) {
        System.out.println((ok ? "  ok    " : "  FAIL  ") + what);
        if (!ok) {
            failures++;
        }
    }

    private static boolean eq(BigDecimal a, String b) {
        return a.compareTo(new BigDecimal(b)) == 0;
    }

    public static void main(String[] args) {
        List<Account> accounts = Db.seedAccounts();

        System.out.println("The four entries from the original screens (Dr Cash / Cr something, 1,000 each):");
        MemoryStore s = new MemoryStore();
        add(s, "utang", 1010, 1100, "1000");
        add(s, "ddaa", 1010, 1130, "1000");
        add(s, "dada", 1010, 1310, "1000");
        add(s, "paid", 1010, 2010, "1000");
        Accounting.Totals t = Accounting.totals(accounts, s.entries());
        check("assets = 1,000 (cash 4,000 less three credited assets)", eq(t.assets(), "1000"));
        check("liabilities = 1,000", eq(t.liabilities(), "1000"));
        check("equity = 0", eq(t.equity(), "0"));
        check("equation balanced", t.balanced());
        check("4 entries", t.entries() == 4);

        List<Accounting.AccountLedger> ledgers = Accounting.ledgers(accounts, s.entries());
        check("5 accounts used", ledgers.size() == 5);
        Accounting.AccountLedger cash = ledgers.get(0);
        check("cash is first and ends at 4,000 DR", cash.account().code() == 1010 && eq(cash.balance(), "4000"));
        check("cash running balances 1000/2000/3000/4000",
                eq(cash.lines().get(0).balance(), "1000") && eq(cash.lines().get(3).balance(), "4000"));
        check("cash balance is normal", !cash.abnormal());
        Accounting.AccountLedger ar = ledgers.get(1);
        check("accounts receivable with a credit balance is flagged abnormal", ar.account().code() == 1100 && ar.abnormal());
        check("accounts payable (credit balance) is normal", !ledgers.get(4).abnormal());

        System.out.println("A fuller scenario with revenue, expenses and adjustments:");
        MemoryStore m = MemoryStore.withSampleData();
        List<Entry> entries = m.entries();
        t = Accounting.totals(accounts, entries);
        // revenue 18,500; expenses 6,000 + 2,000 + 1,500 = 9,500; net income 9,000
        check("revenue 18,500", eq(t.revenue(), "18500"));
        check("expenses 9,500", eq(t.expenses(), "9500"));
        check("net income 9,000", eq(t.netIncome(), "9000"));
        check("equity = capital 100,000 + net income 9,000", eq(t.equity(), "109000"));
        check("assets 113,000 = 4,000 liabilities + 109,000 equity", eq(t.assets(), "113000") && eq(t.liabilities(), "4000"));
        check("equation balanced", t.balanced());

        Accounting.Worksheet w = Accounting.worksheet(accounts, entries);
        check("worksheet net income 9,000", eq(w.netIncome(), "9000"));
        for (int pair = 0; pair < 12; pair += 2) {
            String name = new String[]{"unadjusted", "adjustments", "adjusted", "income statement", "owner's equity", "balance sheet"}[pair / 2];
            check("grand total Dr = Cr: " + name, w.grand()[pair].compareTo(w.grand()[pair + 1]) == 0);
        }
        check("unadjusted total Dr = Cr", w.total()[Accounting.U_DR].compareTo(w.total()[Accounting.U_CR]) == 0);
        check("adjusted total Dr = Cr", w.total()[Accounting.J_DR].compareTo(w.total()[Accounting.J_CR]) == 0);
        Accounting.WsRow rent = w.rows().stream().filter(r -> r.account().code() == 5020).findFirst().orElseThrow();
        check("rent expense: unadjusted 0, adjustment Dr 2,000, adjusted Dr 2,000, in income statement",
                eq(rent.values()[Accounting.U_DR], "0") && eq(rent.values()[Accounting.A_DR], "2000")
                        && eq(rent.values()[Accounting.J_DR], "2000") && eq(rent.values()[Accounting.I_DR], "2000"));
        Accounting.WsRow prepaid = w.rows().stream().filter(r -> r.account().code() == 1320).findFirst().orElseThrow();
        check("prepaid rent: unadjusted Dr 12,000, adjusted Dr 10,000, on the balance sheet",
                eq(prepaid.values()[Accounting.U_DR], "12000") && eq(prepaid.values()[Accounting.J_DR], "10000")
                        && eq(prepaid.values()[Accounting.B_DR], "10000"));

        System.out.println("A net loss:");
        MemoryStore loss = new MemoryStore();
        add(loss, "cap", 1010, 3010, "5000");
        add(loss, "rent", 5020, 1010, "2000");
        Accounting.Worksheet lw = Accounting.worksheet(accounts, loss.entries());
        check("net loss is -2,000", eq(lw.netIncome(), "-2000"));
        for (int pair = 6; pair < 12; pair += 2) {
            check("grand total balances in column pair starting at " + pair, lw.grand()[pair].compareTo(lw.grand()[pair + 1]) == 0);
        }

        System.out.println("Input validation:");
        check("date 20261103 ok", Validate.date("20261103").getDayOfMonth() == 3);
        check("date 2026-11-03 ok", Validate.date("2026-11-03").getMonthValue() == 11);
        check("date 20261340 rejected", rejects(() -> Validate.date("20261340")));
        check("date 20260230 rejected", rejects(() -> Validate.date("20260230")));
        check("amount 1,500.5 -> 1500.50", eq(Validate.amount("1,500.5"), "1500.50"));
        check("amount 0 rejected", rejects(() -> Validate.amount("0")));
        check("amount blank rejected", rejects(() -> Validate.amount("")));
        check("amount -5 rejected", rejects(() -> Validate.amount("-5")));
        check("amount abc rejected", rejects(() -> Validate.amount("abc")));
        check("amount 1.234 rejected", rejects(() -> Validate.amount("1.234")));
        check("amount 99999999999999 rejected", rejects(() -> Validate.amount("99999999999999")));

        System.out.println(failures == 0 ? "\nAll checks passed." : "\n" + failures + " check(s) FAILED.");
        System.exit(failures == 0 ? 0 : 1);
    }

    private static boolean rejects(Runnable r) {
        try {
            r.run();
            return false;
        } catch (IllegalArgumentException e) {
            return true;
        }
    }

    private static void add(MemoryStore s, String desc, int dr, int cr, String amt) {
        s.insert(new Entry(0, java.time.LocalDate.of(2026, 11, 3), "JE" + desc, desc, dr, cr, new BigDecimal(amt), false));
    }
}
