package tala.data;

import tala.logic.*;

import java.util.List;

/*
 * ==============================================================
 *  Store.java   [Data (database)]
 *  WHAT THIS FILE DOES: The list of things the program can ask the data layer to do (get accounts, save an entry, delete an entry...).
 *  USED BY: MySqlStore, MemoryStore
 * ==============================================================
 */

/** Where accounts and entries live. MySqlStore is the real one; MemoryStore is for demo mode and tests. */
public interface Store {

    List<Account> accounts();

    /** All entries (regular and adjusting), ordered by date then id. */
    List<Entry> entries();

    boolean referenceExists(String reference);

    void insert(Entry entry);

    void delete(int id);

    void deleteAll();
}
