package tala.data;

import tala.logic.*;

import java.util.List;
import java.util.function.Supplier;

/*
 * ==============================================================
 *  Repo.java   [Data (database)]
 *  WHAT THIS FILE DOES: The one door the screens use to reach the data. It forwards to whichever Store is active.
 *  USED BY: all the screens
 * ==============================================================
 */

/** Static facade over the active Store. Also keeps the "Connected to MySQL" indicator up to date. */
public final class Repo {

    private static Store store = new MySqlStore();

    private Repo() {
    }

    public static void use(Store s) {
        store = s;
    }

    private static <T> T call(Supplier<T> action) {
        try {
            T result = action.get();
            Status.set(true);
            return result;
        } catch (DbException e) {
            if (e.isConnectionProblem()) {
                Status.set(false);
            }
            throw e;
        }
    }

    public static List<Account> accounts() {
        return call(store::accounts);
    }

    public static List<Entry> entries() {
        return call(store::entries);
    }

    public static boolean referenceExists(String reference) {
        return call(() -> store.referenceExists(reference));
    }

    public static void insert(Entry entry) {
        call(() -> {
            store.insert(entry);
            return null;
        });
    }

    public static void delete(int id) {
        call(() -> {
            store.delete(id);
            return null;
        });
    }

    public static void deleteAll() {
        call(() -> {
            store.deleteAll();
            return null;
        });
    }
}
