package tala.data;

import java.sql.SQLException;

/*
 * ==============================================================
 *  DbException.java   [Data (database)]
 *  WHAT THIS FILE DOES: The error type used when something goes wrong with the database.
 *  USED BY: data and ui files
 * ==============================================================
 */

/** Unchecked wrapper so screens don't need try/catch around every query. */
public class DbException extends RuntimeException {

    private final boolean connectionProblem;

    public DbException(SQLException cause) {
        super(cause.getMessage() == null ? cause.toString() : cause.getMessage(), cause);
        String state = cause.getSQLState();
        connectionProblem = (state != null && state.startsWith("08"))
                || cause.getClass().getSimpleName().contains("Communications");
    }

    public DbException(String message) {
        super(message);
        connectionProblem = false;
    }

    /** True when the server could not be reached (as opposed to e.g. a constraint error). */
    public boolean isConnectionProblem() {
        return connectionProblem;
    }
}
