package tala.data;

import tala.logic.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/*
 * ==============================================================
 *  Db.java   [Data (database)]
 *  WHAT THIS FILE DOES: Connection settings, the SQL that creates the tables, and the starter chart of accounts.
 *  USED BY: MySqlStore, Main
 * ==============================================================
 */

/**
 * MySQL connection settings, schema creation and the starter chart of accounts.
 * Settings are read from / saved to tala.properties in the folder the app is started from.
 * Run "java -cp out tala.data.Db" to print the schema as plain SQL.
 */
public final class Db {

    public static String host = "localhost";
    public static String port = "3306";
    public static String database = "tala";
    public static String user = "root";
    public static String password = "";

    private static final File FILE = new File("tala.properties");

    private Db() {
    }

    // ---------------------------------------------------------------- settings

    public static void load() {
        if (!FILE.isFile()) {
            return;
        }
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(FILE)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        host = p.getProperty("host", host);
        port = p.getProperty("port", port);
        database = p.getProperty("database", database);
        user = p.getProperty("user", user);
        password = p.getProperty("password", password);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("host", host);
        p.setProperty("port", port);
        p.setProperty("database", database);
        p.setProperty("user", user);
        p.setProperty("password", password);
        try (FileOutputStream out = new FileOutputStream(FILE)) {
            p.store(out, "TALA database settings");
        } catch (IOException ignored) {
            // not fatal: the settings just won't be remembered
        }
    }

    // -------------------------------------------------------------- connection

    private static String url(boolean withDatabase) {
        return "jdbc:mysql://" + host + ":" + port + "/" + (withDatabase ? database : "")
                + "?allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8"
                + "&connectTimeout=5000&socketTimeout=20000";
    }

    private static void loadDriver() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC driver not found. Download mysql-connector-j (the .jar) "
                    + "and put it in the lib folder, then start TALA again.");
        }
    }

    public static Connection connect() throws SQLException {
        loadDriver();
        return DriverManager.getConnection(url(true), user, password);
    }

    /** Creates the database, tables and starter accounts if they are missing. */
    public static void initialize() throws SQLException {
        if (!database.matches("[A-Za-z0-9_]{1,64}")) {
            throw new SQLException("Database name may only contain letters, digits and underscores.");
        }
        loadDriver();

        SQLException createError = null;
        try (Connection c = DriverManager.getConnection(url(false), user, password);
             Statement s = c.createStatement()) {
            s.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + database + "` CHARACTER SET utf8mb4");
        } catch (SQLException e) {
            createError = e; // maybe the user may not create databases but the database already exists
        }

        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.executeUpdate(ACCOUNTS_DDL);
            s.executeUpdate(ENTRIES_DDL);
            try (ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM accounts")) {
                rs.next();
                if (rs.getInt(1) == 0) {
                    seed(c);
                }
            }
        } catch (SQLException e) {
            throw createError != null ? createError : e;
        }
    }

    private static void seed(Connection c) throws SQLException {
        String sql = "INSERT INTO accounts (code, name, type, normal_balance) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (String[] row : SEED) {
                ps.setInt(1, Integer.parseInt(row[0]));
                ps.setString(2, row[1]);
                ps.setString(3, row[2]);
                ps.setString(4, row[3]);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    // ------------------------------------------------------------------ schema

    static final String ACCOUNTS_DDL = """
            CREATE TABLE IF NOT EXISTS accounts (
              code            INT          NOT NULL PRIMARY KEY,
              name            VARCHAR(80)  NOT NULL UNIQUE,
              type            ENUM('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE') NOT NULL,
              normal_balance  ENUM('DEBIT','CREDIT') NOT NULL,
              active          TINYINT(1)   NOT NULL DEFAULT 1
            )""";

    static final String ENTRIES_DDL = """
            CREATE TABLE IF NOT EXISTS journal_entries (
              id             INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
              entry_date     DATE          NOT NULL,
              reference      VARCHAR(20)   NOT NULL UNIQUE,
              description    VARCHAR(255)  NOT NULL,
              debit_code     INT           NOT NULL,
              credit_code    INT           NOT NULL,
              amount         DECIMAL(15,2) NOT NULL,
              is_adjustment  TINYINT(1)    NOT NULL DEFAULT 0,
              created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
              CONSTRAINT fk_entry_debit  FOREIGN KEY (debit_code)  REFERENCES accounts (code),
              CONSTRAINT fk_entry_credit FOREIGN KEY (credit_code) REFERENCES accounts (code),
              CONSTRAINT chk_entry_amount CHECK (amount > 0),
              CONSTRAINT chk_entry_accounts CHECK (debit_code <> credit_code)
            )""";

    /** code, name, type, normal balance */
    public static final String[][] SEED = {
            {"1010", "Cash", "ASSET", "DEBIT"},
            {"1100", "Accounts Receivable", "ASSET", "DEBIT"},
            {"1110", "Allowance for Doubtful Accounts", "ASSET", "CREDIT"},
            {"1120", "Notes Receivable", "ASSET", "DEBIT"},
            {"1130", "Interest Receivable", "ASSET", "DEBIT"},
            {"1200", "Inventory", "ASSET", "DEBIT"},
            {"1300", "Supplies", "ASSET", "DEBIT"},
            {"1310", "Prepaid Insurance", "ASSET", "DEBIT"},
            {"1320", "Prepaid Rent", "ASSET", "DEBIT"},
            {"1400", "Advances to Employees", "ASSET", "DEBIT"},
            {"1500", "Office Equipment", "ASSET", "DEBIT"},
            {"1510", "Furniture", "ASSET", "DEBIT"},
            {"1520", "Vehicles", "ASSET", "DEBIT"},
            {"1530", "Accumulated Depreciation", "ASSET", "CREDIT"},
            {"1600", "Land", "ASSET", "DEBIT"},
            {"1610", "Building", "ASSET", "DEBIT"},
            {"2010", "Accounts Payable", "LIABILITY", "CREDIT"},
            {"2020", "Salaries Payable", "LIABILITY", "CREDIT"},
            {"2030", "Taxes Payable", "LIABILITY", "CREDIT"},
            {"2040", "Interest Payable", "LIABILITY", "CREDIT"},
            {"2050", "Notes Payable", "LIABILITY", "CREDIT"},
            {"2060", "Unearned Revenue", "LIABILITY", "CREDIT"},
            {"3010", "Owner's Capital", "EQUITY", "CREDIT"},
            {"3020", "Owner's Drawings", "EQUITY", "DEBIT"},
            {"4010", "Service Revenue", "REVENUE", "CREDIT"},
            {"4020", "Sales Revenue", "REVENUE", "CREDIT"},
            {"4030", "Interest Income", "REVENUE", "CREDIT"},
            {"5010", "Salaries Expense", "EXPENSE", "DEBIT"},
            {"5020", "Rent Expense", "EXPENSE", "DEBIT"},
            {"5030", "Supplies Expense", "EXPENSE", "DEBIT"},
            {"5040", "Utilities Expense", "EXPENSE", "DEBIT"},
            {"5050", "Insurance Expense", "EXPENSE", "DEBIT"},
            {"5060", "Depreciation Expense", "EXPENSE", "DEBIT"},
            {"5070", "Interest Expense", "EXPENSE", "DEBIT"},
            {"5080", "Bad Debts Expense", "EXPENSE", "DEBIT"},
            {"5090", "Miscellaneous Expense", "EXPENSE", "DEBIT"},
    };

    public static List<Account> seedAccounts() {
        List<Account> list = new ArrayList<>();
        for (String[] r : SEED) {
            list.add(new Account(Integer.parseInt(r[0]), r[1], r[2], r[3], true));
        }
        return list;
    }

    /** The whole schema as a plain SQL script (what initialize() does, for MySQL Workbench users). */
    public static String schemaSql() {
        StringBuilder sb = new StringBuilder();
        sb.append("-- TALA schema. Generated by: java -cp out tala.data.Db > schema.sql\n");
        sb.append("-- The app creates all of this by itself on first start; use this file only if you prefer to do it by hand.\n\n");
        sb.append("CREATE DATABASE IF NOT EXISTS `").append(database).append("` CHARACTER SET utf8mb4;\n");
        sb.append("USE `").append(database).append("`;\n\n");
        sb.append(ACCOUNTS_DDL).append(";\n\n");
        sb.append(ENTRIES_DDL).append(";\n\n");
        sb.append("INSERT IGNORE INTO accounts (code, name, type, normal_balance) VALUES\n");
        for (int i = 0; i < SEED.length; i++) {
            String[] r = SEED[i];
            sb.append("  (").append(r[0]).append(", '").append(r[1].replace("'", "''")).append("', '")
                    .append(r[2]).append("', '").append(r[3]).append("')")
                    .append(i < SEED.length - 1 ? ",\n" : ";\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.print(schemaSql());
    }
}
