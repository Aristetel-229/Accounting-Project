package tala.data;

import tala.logic.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/*
 * ==============================================================
 *  MySqlStore.java   [Data (database)]
 *  WHAT THIS FILE DOES: The real Store: reads and writes the MySQL database.
 *  USED BY: Repo
 * ==============================================================
 */

/** JDBC implementation of Store. Opens a short-lived connection per call, which is plenty for a local app. */
public final class MySqlStore implements Store {

    @Override
    public List<Account> accounts() {
        String sql = "SELECT code, name, type, normal_balance, active FROM accounts ORDER BY code";
        try (Connection c = Db.connect(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            List<Account> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new Account(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getBoolean(5)));
            }
            return list;
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }

    @Override
    public List<Entry> entries() {
        String sql = "SELECT id, entry_date, reference, description, debit_code, credit_code, amount, is_adjustment "
                + "FROM journal_entries ORDER BY entry_date, id";
        try (Connection c = Db.connect(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            List<Entry> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new Entry(rs.getInt(1), rs.getObject(2, LocalDate.class), rs.getString(3), rs.getString(4),
                        rs.getInt(5), rs.getInt(6), rs.getBigDecimal(7), rs.getBoolean(8)));
            }
            return list;
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }

    @Override
    public boolean referenceExists(String reference) {
        try (Connection c = Db.connect();
             PreparedStatement ps = c.prepareStatement("SELECT 1 FROM journal_entries WHERE reference = ?")) {
            ps.setString(1, reference);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }

    @Override
    public void insert(Entry e) {
        String sql = "INSERT INTO journal_entries "
                + "(entry_date, reference, description, debit_code, credit_code, amount, is_adjustment) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, e.date());
            ps.setString(2, e.reference());
            ps.setString(3, e.description());
            ps.setInt(4, e.debitCode());
            ps.setInt(5, e.creditCode());
            ps.setBigDecimal(6, e.amount());
            ps.setBoolean(7, e.adjustment());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new DbException(ex);
        }
    }

    @Override
    public void delete(int id) {
        try (Connection c = Db.connect();
             PreparedStatement ps = c.prepareStatement("DELETE FROM journal_entries WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }

    @Override
    public void deleteAll() {
        try (Connection c = Db.connect(); Statement s = c.createStatement()) {
            s.executeUpdate("DELETE FROM journal_entries");
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }
}
