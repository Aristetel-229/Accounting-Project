package tala.data;

import tala.logic.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*
 * ==============================================================
 *  MemoryStore.java   [Data (database)]
 *  WHAT THIS FILE DOES: A fake Store that keeps sample data in memory (used by --demo and the tests). Nothing is saved.
 *  USED BY: Repo, tests
 * ==============================================================
 */

/** In-memory Store used by "--demo" mode and the tests. Nothing is saved. */
public final class MemoryStore implements Store {

    private final List<Account> accounts = Db.seedAccounts();
    private final List<Entry> entries = new ArrayList<>();
    private int nextId = 1;

    @Override
    public List<Account> accounts() {
        return List.copyOf(accounts);
    }

    @Override
    public List<Entry> entries() {
        List<Entry> copy = new ArrayList<>(entries);
        copy.sort(Comparator.comparing(Entry::date).thenComparingInt(Entry::id));
        return copy;
    }

    @Override
    public boolean referenceExists(String reference) {
        return entries.stream().anyMatch(e -> e.reference().equals(reference));
    }

    @Override
    public void insert(Entry e) {
        entries.add(new Entry(nextId++, e.date(), e.reference(), e.description(),
                e.debitCode(), e.creditCode(), e.amount(), e.adjustment()));
    }

    @Override
    public void delete(int id) {
        entries.removeIf(e -> e.id() == id);
    }

    @Override
    public void deleteAll() {
        entries.clear();
    }

    /** A small, coherent set of transactions for the demo and for screenshots. */
    public static MemoryStore withSampleData() {
        MemoryStore s = new MemoryStore();
        s.add(2026, 11, 1, "JE100001", "Owner invested cash", 1010, 3010, "100000.00", false);
        s.add(2026, 11, 2, "JE100002", "Bought office equipment for cash", 1500, 1010, "25000.00", false);
        s.add(2026, 11, 3, "JE100003", "Paid 6 months rent in advance", 1320, 1010, "12000.00", false);
        s.add(2026, 11, 5, "JE100004", "Bought supplies on account", 1300, 2010, "4000.00", false);
        s.add(2026, 11, 8, "JE100005", "Earned service revenue in cash", 1010, 4010, "18500.00", false);
        s.add(2026, 11, 15, "JE100006", "Paid salaries", 5010, 1010, "6000.00", false);
        s.add(2026, 11, 30, "AJ200001", "Rent used up for November", 5020, 1320, "2000.00", true);
        s.add(2026, 11, 30, "AJ200002", "Supplies used during November", 5030, 1300, "1500.00", true);
        return s;
    }

    private void add(int y, int m, int d, String ref, String desc, int dr, int cr, String amt, boolean adj) {
        insert(new Entry(0, LocalDate.of(y, m, d), ref, desc, dr, cr, new BigDecimal(amt), adj));
    }
}
