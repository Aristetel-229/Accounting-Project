package tala.data;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/*
 * ==============================================================
 *  Status.java   [Data (database)]
 *  WHAT THIS FILE DOES: Remembers if MySQL is connected so the top bar can show the green or red badge.
 *  USED BY: MainFrame, Repo
 * ==============================================================
 */

/** Tracks whether the database is reachable so the top bar can show it. Used on the Swing thread only. */
public final class Status {

    private static boolean connected = true;
    private static boolean demo = false;
    private static final List<Consumer<Boolean>> listeners = new ArrayList<>();

    private Status() {
    }

    public static boolean connected() {
        return connected;
    }

    public static void set(boolean value) {
        if (value != connected) {
            connected = value;
            for (Consumer<Boolean> l : listeners) {
                l.accept(value);
            }
        }
    }

    public static boolean demo() {
        return demo;
    }

    public static void setDemo(boolean value) {
        demo = value;
    }

    public static void onChange(Consumer<Boolean> listener) {
        listeners.add(listener);
    }
}
