package tala;

import tala.ui.*;
import tala.data.*;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/*
 * ==============================================================
 *  Main.java   [START HERE]
 *  WHAT THIS FILE DOES: Starts the program. It connects to MySQL (or loads demo data with --demo) and then opens the main window.
 *  USED BY: MainFrame (the window)
 * ==============================================================
 */

/**
 * TALA - a small double-entry accounting app (Java Swing + MySQL).
 *
 * <pre>
 *   java -cp "out:lib/*" tala.Main            normal start, uses MySQL
 *   java -cp "out:lib/*" tala.Main --demo     sample data in memory, no MySQL needed
 * </pre>
 * (On Windows use ";" instead of ":" in the class path.)
 */
public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        boolean demo = false;
        for (String a : args) {
            if (a.equals("--demo")) {
                demo = true;
            }
        }
        final boolean demoMode = demo;

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // keep the default look and feel
            }

            if (demoMode) {
                Repo.use(MemoryStore.withSampleData());
                Status.setDemo(true);
            } else {
                Db.load();
                if (!DbSettingsDialog.connectLoop(null, false)) {
                    System.exit(0);
                }
            }
            new MainFrame().setVisible(true);
        });
    }
}
