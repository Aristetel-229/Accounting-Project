package tala.logic;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * ==============================================================
 *  Accounting.java   [Rules (logic)]
 *  WHAT THIS FILE DOES: ALL the accounting math: dashboard totals, ledger running balances and the 12-column worksheet. No screens and no database in here, so it is the easiest file to study.
 *  USED BY: Dashboard, Ledger and Worksheet screens
 * ==============================================================
 */

/** All bookkeeping calculations. Pure functions over accounts and entries, no UI and no database. */
public final class Accounting {

    private static final BigDecimal ZERO = BigDecimal.ZERO.setScale(2);

    private Accounting() {
    }

    // ------------------------------------------------------------------ dashboard

    /** equity already includes net income. */
    public record Totals(BigDecimal assets, BigDecimal liabilities, BigDecimal equity,
                         BigDecimal revenue, BigDecimal expenses, BigDecimal netIncome, int entries) {
        public boolean balanced() {
            return assets.compareTo(liabilities.add(equity)) == 0;
        }

        public BigDecimal difference() {
            return assets.subtract(liabilities.add(equity));
        }
    }

    public static Totals totals(List<Account> accounts, List<Entry> entries) {
        Map<Integer, BigDecimal> net = netByCode(entries);
        BigDecimal assets = ZERO, liabilities = ZERO, equity = ZERO, revenue = ZERO, expenses = ZERO;
        for (Account a : accounts) {
            BigDecimal n = net.getOrDefault(a.code(), ZERO); // debits minus credits
            switch (a.type()) {
                case "ASSET" -> assets = assets.add(n);          // contra assets are credit-normal, so they subtract
                case "LIABILITY" -> liabilities = liabilities.subtract(n);
                case "EQUITY" -> equity = equity.subtract(n);    // drawings are debit-normal, so they subtract
                case "REVENUE" -> revenue = revenue.subtract(n);
                case "EXPENSE" -> expenses = expenses.add(n);
                default -> { }
            }
        }
        BigDecimal netIncome = revenue.subtract(expenses);
        return new Totals(assets, liabilities, equity.add(netIncome), revenue, expenses, netIncome, entries.size());
    }

    /** debits minus credits per account code */
    private static Map<Integer, BigDecimal> netByCode(List<Entry> entries) {
        Map<Integer, BigDecimal> net = new HashMap<>();
        for (Entry e : entries) {
            net.merge(e.debitCode(), e.amount(), BigDecimal::add);
            net.merge(e.creditCode(), e.amount().negate(), BigDecimal::add);
        }
        return net;
    }

    // --------------------------------------------------------------------- ledger

    /** balance is signed: positive = debit balance, negative = credit balance. */
    public record LedgerLine(LocalDate date, String description, String reference,
                             BigDecimal debit, BigDecimal credit, BigDecimal balance) {
    }

    public record AccountLedger(Account account, List<LedgerLine> lines,
                                BigDecimal totalDebit, BigDecimal totalCredit, BigDecimal balance) {
        /** True when the ending balance sits on the opposite side of the account's normal balance. */
        public boolean abnormal() {
            int sign = balance.signum();
            return sign != 0 && (sign > 0) != account.isDebitNormal();
        }
    }

    /** One ledger per account that has at least one entry, in account-code order. */
    public static List<AccountLedger> ledgers(List<Account> accounts, List<Entry> entries) {
        List<AccountLedger> result = new ArrayList<>();
        for (Account a : accounts) {
            List<LedgerLine> lines = new ArrayList<>();
            BigDecimal running = ZERO, totalDr = ZERO, totalCr = ZERO;
            for (Entry e : entries) {
                BigDecimal dr = ZERO, cr = ZERO;
                if (e.debitCode() == a.code()) {
                    dr = e.amount();
                } else if (e.creditCode() == a.code()) {
                    cr = e.amount();
                } else {
                    continue;
                }
                running = running.add(dr).subtract(cr);
                totalDr = totalDr.add(dr);
                totalCr = totalCr.add(cr);
                lines.add(new LedgerLine(e.date(), e.description(), e.reference(), dr, cr, running));
            }
            if (!lines.isEmpty()) {
                result.add(new AccountLedger(a, lines, totalDr, totalCr, running));
            }
        }
        return result;
    }

    // ------------------------------------------------------------------ worksheet

    public static final int U_DR = 0, U_CR = 1, A_DR = 2, A_CR = 3, J_DR = 4, J_CR = 5,
            I_DR = 6, I_CR = 7, O_DR = 8, O_CR = 9, B_DR = 10, B_CR = 11;

    /** values has 12 slots in the column order above: Unadjusted, Adjustments, Adjusted, Income Stmt, Owner's Equity, Balance Sheet (Dr, Cr each). */
    public record WsRow(Account account, BigDecimal[] values) {
    }

    /**
     * total: column totals of the account rows. netIncome / ownersEquity: the balancing rows
     * (only the Income Statement, Owner's Equity and Balance Sheet columns are used). grand: totals after balancing.
     */
    public record Worksheet(List<WsRow> rows, BigDecimal[] total, BigDecimal[] netIncomeRow,
                            BigDecimal[] ownersEquityRow, BigDecimal[] grand, BigDecimal netIncome) {
    }

    private static BigDecimal[] blankRow() {
        BigDecimal[] row = new BigDecimal[12];
        Arrays.fill(row, ZERO);
        return row;
    }

    /** Puts a signed net (debit positive) into the Dr or Cr slot. */
    private static void place(BigDecimal[] row, int drSlot, BigDecimal net) {
        if (net.signum() > 0) {
            row[drSlot] = net;
        } else if (net.signum() < 0) {
            row[drSlot + 1] = net.negate();
        }
    }

    public static Worksheet worksheet(List<Account> accounts, List<Entry> entries) {
        // per account: regular debit, regular credit, adjusting debit, adjusting credit
        Map<Integer, BigDecimal[]> sums = new HashMap<>();
        for (Entry e : entries) {
            int offset = e.adjustment() ? 2 : 0;
            sums.computeIfAbsent(e.debitCode(), k -> blankRow())[offset] =
                    sums.get(e.debitCode())[offset].add(e.amount());
            sums.computeIfAbsent(e.creditCode(), k -> blankRow())[offset + 1] =
                    sums.get(e.creditCode())[offset + 1].add(e.amount());
        }

        List<WsRow> rows = new ArrayList<>();
        BigDecimal[] total = blankRow();
        for (Account a : accounts) {
            BigDecimal[] s = sums.get(a.code());
            if (s == null) {
                continue;
            }
            BigDecimal[] v = blankRow();
            BigDecimal unadjusted = s[0].subtract(s[1]);
            place(v, U_DR, unadjusted);
            v[A_DR] = s[2];
            v[A_CR] = s[3];
            BigDecimal adjusted = unadjusted.add(s[2]).subtract(s[3]);
            place(v, J_DR, adjusted);

            int target = switch (a.type()) {
                case "REVENUE", "EXPENSE" -> I_DR;
                case "EQUITY" -> O_DR;
                default -> B_DR; // assets and liabilities
            };
            place(v, target, adjusted);

            for (int i = 0; i < 12; i++) {
                total[i] = total[i].add(v[i]);
            }
            rows.add(new WsRow(a, v));
        }

        // Net income balances the income statement and flows into owner's equity.
        BigDecimal netIncome = total[I_CR].subtract(total[I_DR]);
        BigDecimal[] niRow = blankRow();
        if (netIncome.signum() >= 0) {
            niRow[I_DR] = netIncome;   // income statement debit side needs the profit to balance
            niRow[O_CR] = netIncome;   // and it increases owner's equity
        } else {
            niRow[I_CR] = netIncome.negate();
            niRow[O_DR] = netIncome.negate();
        }

        // Ending owner's equity balances the equity column and flows into the balance sheet.
        BigDecimal equity = total[O_CR].add(niRow[O_CR]).subtract(total[O_DR]).subtract(niRow[O_DR]);
        BigDecimal[] oeRow = blankRow();
        if (equity.signum() >= 0) {
            oeRow[O_DR] = equity;
            oeRow[B_CR] = equity;
        } else {
            oeRow[O_CR] = equity.negate();
            oeRow[B_DR] = equity.negate();
        }

        BigDecimal[] grand = blankRow();
        for (int i = 0; i < 12; i++) {
            grand[i] = total[i].add(niRow[i]).add(oeRow[i]);
        }
        return new Worksheet(rows, total, niRow, oeRow, grand, netIncome);
    }
}
