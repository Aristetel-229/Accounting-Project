package tala.logic;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.util.Locale;

/*
 * ==============================================================
 *  Fmt.java   [Rules (logic)]
 *  WHAT THIS FILE DOES: Formats numbers and dates, e.g. 1234.5 becomes 1,234.50 and the peso sign is added.
 *  USED BY: every screen
 * ==============================================================
 */

/** Number and date formatting used on every screen. */
public final class Fmt {

    public static final String PESO = "₱";

    private static final String[] MONTHS =
            {"Jan.", "Feb.", "Mar.", "Apr.", "May", "June", "July", "Aug.", "Sept.", "Oct.", "Nov.", "Dec."};

    private Fmt() {
    }

    /** 1234.5 -> "1,234.50" */
    public static String num(BigDecimal v) {
        return new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US)).format(v);
    }

    /** 1234.5 -> "₱1,234.50" */
    public static String peso(BigDecimal v) {
        return v.signum() < 0 ? "-" + PESO + num(v.negate()) : PESO + num(v);
    }

    /** Empty text for zero, otherwise the number. Used in the worksheet so empty cells stay empty. */
    public static String blankZero(BigDecimal v) {
        return v.signum() == 0 ? "" : num(v);
    }

    /** 20261103 */
    public static String compact(LocalDate d) {
        return String.format("%04d%02d%02d", d.getYear(), d.getMonthValue(), d.getDayOfMonth());
    }

    /** "Nov. 3" */
    public static String monthDay(LocalDate d) {
        return MONTHS[d.getMonthValue() - 1] + " " + d.getDayOfMonth();
    }

    /** "Nov. 3, 2026" */
    public static String longDate(LocalDate d) {
        return monthDay(d) + ", " + d.getYear();
    }
}
