package tala.logic;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/*
 * ==============================================================
 *  Validate.java   [Rules (logic)]
 *  WHAT THIS FILE DOES: Checks what the user typed (date and amount) and gives a friendly message when something is wrong.
 *  USED BY: EntryForm
 * ==============================================================
 */

/** Input checks for the entry form. Every failure carries a message that is safe to show to the user. */
public final class Validate {

    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("uuuuMMdd").withResolverStyle(ResolverStyle.STRICT);
    private static final BigDecimal LIMIT = new BigDecimal("10000000000000"); // DECIMAL(15,2) holds up to 9,999,999,999,999.99

    private Validate() {
    }

    /** Accepts 20261103, 2026-11-03 or 2026/11/03. */
    public static LocalDate date(String text) {
        String s = text == null ? "" : text.trim().replace("-", "").replace("/", "");
        try {
            if (s.length() != 8) {
                throw new DateTimeParseException("length", s, 0);
            }
            return LocalDate.parse(s, DATE);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Enter a real date as YYYYMMDD, for example 20261103");
        }
    }

    public static BigDecimal amount(String text) {
        String s = text == null ? "" : text.trim().replace(",", "").replace(Fmt.PESO, "").replace(" ", "");
        if (s.isEmpty()) {
            throw new IllegalArgumentException("Enter an amount above zero");
        }
        BigDecimal v;
        try {
            v = new BigDecimal(s);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("The amount must be a number, for example 1500.00");
        }
        if (v.signum() <= 0) {
            throw new IllegalArgumentException("Enter an amount above zero");
        }
        if (v.stripTrailingZeros().scale() > 2) {
            throw new IllegalArgumentException("Use at most 2 decimal places");
        }
        if (v.compareTo(LIMIT) >= 0) {
            throw new IllegalArgumentException("That amount is too large");
        }
        return v.setScale(2);
    }
}
