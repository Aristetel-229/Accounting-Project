package tala.logic;

/*
 * ==============================================================
 *  Account.java   [Rules (logic)]
 *  WHAT THIS FILE DOES: One account in the chart of accounts (code, name, type, normal balance).
 *  USED BY: Accounting, the screens
 * ==============================================================
 */

/** One row of the chart of accounts. type: ASSET, LIABILITY, EQUITY, REVENUE, EXPENSE. normal: DEBIT or CREDIT. */
public record Account(int code, String name, String type, String normal, boolean active) {

    public boolean isDebitNormal() {
        return "DEBIT".equals(normal);
    }

    /** "ASSET" -> "Asset" */
    public String typeLabel() {
        return type.charAt(0) + type.substring(1).toLowerCase();
    }

    public String label() {
        return code + "  " + name;
    }

    @Override
    public String toString() {
        return label();
    }
}
