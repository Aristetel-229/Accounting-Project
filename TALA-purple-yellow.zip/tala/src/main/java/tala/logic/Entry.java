package tala.logic;

import java.math.BigDecimal;
import java.time.LocalDate;

/*
 * ==============================================================
 *  Entry.java   [Rules (logic)]
 *  WHAT THIS FILE DOES: One posted journal entry: one account debited, one account credited, one amount.
 *  USED BY: Accounting, the screens
 * ==============================================================
 */

/**
 * A posted journal entry: one debit account, one credit account, one amount.
 * adjustment = true marks an adjusting entry (shown in the Adjustments columns of the 12 Columnar).
 */
public record Entry(int id, LocalDate date, String reference, String description,
                    int debitCode, int creditCode, BigDecimal amount, boolean adjustment) {
}
