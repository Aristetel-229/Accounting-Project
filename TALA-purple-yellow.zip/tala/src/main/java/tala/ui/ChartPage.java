package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.Color;

/*
 * ==============================================================
 *  ChartPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: Chart of Accounts screen: the list of accounts you can use, with type and normal balance.
 *  USED BY: MainFrame
 * ==============================================================
 */

public final class ChartPage extends Page {

    private final Grid grid = new Grid("Code", "Account Name", "Type", "Normal Balance", "Status")
            .widths(80, 340, 130, 140, 100);

    public ChartPage() {
        super("Chart of Accounts", "Chart of Accounts", "All the accounts your business can use, grouped by type.");

        Theme.Btn refresh = new Theme.Btn("Refresh", Theme.Kind.SECONDARY);
        refresh.addActionListener(e -> {
            try {
                refresh();
            } catch (DbException ex) {
                Theme.error(this, ex);
            }
        });
        addAction(refresh);

        JTable table = grid.table(false);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Theme.LINE));
        sp.getViewport().setBackground(Color.WHITE);

        Theme.Card card = new Theme.Card();
        card.setLayout(new BorderLayout());
        card.add(sp, BorderLayout.CENTER);
        setContent(card, false);
    }

    @Override
    public void refresh() {
        grid.clear();
        for (Account a : Repo.accounts()) {
            grid.add(Grid.NORMAL, String.valueOf(a.code()), a.name(), a.type(), a.normal(),
                    a.active() ? "Active" : "Inactive");
        }
        grid.done();
    }
}
