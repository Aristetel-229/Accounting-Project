package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/*
 * ==============================================================
 *  WorksheetPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: 12 Columnar screen (worksheet). Shows the CSV download and the Add Adjustment button. The Balance Sheet columns end in 0.00 when debit equals credit.
 *  USED BY: MainFrame
 * ==============================================================
 */

/** The 12-column worksheet: unadjusted, adjustments, adjusted, income statement, owner's equity, balance sheet. */
public final class WorksheetPage extends Page {

    private static final String[] GROUPS =
            {"Unadjusted", "Adjustments", "Adjusted", "Income Stmt", "Owner's Equity", "Balance Sheet"};

    private final Grid grid;
    private final JTable table;
    private final JLabel note = Theme.label("", Font.PLAIN, 13, Theme.MUTED);
    private Accounting.Worksheet current;

    public WorksheetPage() {
        super("12 Columnar", "12 Columnar",
                "Unadjusted trial balance, adjustments, adjusted trial balance, income statement, owner's equity and balance sheet. Amounts in "
                        + Fmt.PESO + ".");

        String[] cols = new String[14];
        cols[0] = "Code";
        cols[1] = "Account";
        for (int i = 0; i < 12; i++) {
            cols[i + 2] = "<html><div style='text-align:center'>" + GROUPS[i / 2] + "<br>" + (i % 2 == 0 ? "Dr" : "Cr")
                    + "</div></html>";
        }
        int[] numeric = new int[12];
        int[] widths = new int[14];
        widths[0] = 60;
        widths[1] = 220;
        for (int i = 0; i < 12; i++) {
            numeric[i] = i + 2;
            widths[i + 2] = 105;
        }
        grid = new Grid(cols).rightAlign(numeric).widths(widths);
        table = grid.table(false);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        Theme.Btn csv = new Theme.Btn("Download CSV", Theme.Kind.SECONDARY);
        csv.addActionListener(e -> downloadCsv());
        Theme.Btn adjust = new Theme.Btn("Add Adjustment", Theme.Kind.ACCENT);
        adjust.addActionListener(e -> addAdjustment());
        Theme.Btn refresh = new Theme.Btn("Refresh", Theme.Kind.SECONDARY);
        refresh.addActionListener(e -> guarded());
        addAction(csv);
        addAction(adjust);
        addAction(refresh);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Theme.LINE));
        sp.getViewport().setBackground(Color.WHITE);

        Theme.Card card = new Theme.Card();
        card.setLayout(new BorderLayout(0, 12));
        card.add(sp, BorderLayout.CENTER);
        card.add(note, BorderLayout.SOUTH);
        setContent(card, false);
    }

    private void guarded() {
        try {
            refresh();
        } catch (DbException e) {
            Theme.error(this, e);
        }
    }

    private void addAdjustment() {
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this), "Add Adjustment", JDialog.DEFAULT_MODALITY_TYPE);
        EntryForm form = new EntryForm(true);
        try {
            form.reload();
        } catch (DbException e) {
            Theme.error(this, e);
            return;
        }
        form.setOnPosted(() -> {
            dialog.dispose();
            guarded();
        });
        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setBackground(Theme.BG);
        body.setBorder(new EmptyBorder(18, 18, 18, 18));
        JLabel hint = Theme.label("<html>An adjusting entry (accrual, deferral, depreciation...) appears in the Adjustments columns "
                + "and changes the adjusted balances.</html>", Font.PLAIN, 12, Theme.MUTED);
        body.add(hint, BorderLayout.NORTH);
        body.add(form, BorderLayout.CENTER);
        dialog.setContentPane(body);
        dialog.pack();
        dialog.setMinimumSize(new java.awt.Dimension(760, dialog.getHeight()));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private static String cell(BigDecimal v) {
        return Fmt.blankZero(v);
    }

    /**
     * What the Balance Sheet columns show on the very last (GRAND TOTAL) row.
     * When Debit equals Credit, the leftover difference is zero, so both cells show 0.00.
     * If the books are NOT balanced, the real difference is shown on the bigger side so a mistake is never hidden.
     * Returns {debitText, creditText}.
     */
    private static String[] balanceSheetEnding(BigDecimal[] grand) {
        BigDecimal diff = grand[Accounting.B_DR].subtract(grand[Accounting.B_CR]);
        if (diff.signum() == 0) {
            return new String[]{Fmt.num(BigDecimal.ZERO), Fmt.num(BigDecimal.ZERO)};
        }
        return diff.signum() > 0 ? new String[]{Fmt.num(diff), ""} : new String[]{"", Fmt.num(diff.negate())};
    }

    private void addTotalRow(String label, BigDecimal[] v) {
        addTotalRow(label, v, false);
    }

    /** endingZero = true is used only for GRAND TOTAL: its Balance Sheet cells show the ending difference (0.00). */
    private void addTotalRow(String label, BigDecimal[] v, boolean endingZero) {
        String[] cells = new String[14];
        cells[0] = "";
        cells[1] = label;
        for (int i = 0; i < 12; i++) {
            cells[i + 2] = cell(v[i]);
        }
        if (endingZero) {
            String[] end = balanceSheetEnding(v);
            cells[Accounting.B_DR + 2] = end[0];
            cells[Accounting.B_CR + 2] = end[1];
        }
        grid.add(Grid.TOTAL, cells);
    }

    @Override
    public void refresh() {
        current = Accounting.worksheet(Repo.accounts(), Repo.entries());
        grid.clear();
        for (Accounting.WsRow r : current.rows()) {
            String[] cells = new String[14];
            cells[0] = String.valueOf(r.account().code());
            cells[1] = r.account().name();
            for (int i = 0; i < 12; i++) {
                cells[i + 2] = cell(r.values()[i]);
            }
            grid.add(Grid.NORMAL, cells);
        }
        if (current.rows().isEmpty()) {
            grid.add(Grid.NOTE, "", "No entries yet. Record a transaction under Journal Entry.");
            note.setText(" ");
        } else {
            addTotalRow("TOTAL", current.total());
            addTotalRow("NET INCOME", current.netIncomeRow());
            addTotalRow("OWNER'S EQUITY", current.ownersEquityRow());
            addTotalRow("GRAND TOTAL", current.grand(), true);
            BigDecimal ni = current.netIncome();
            note.setText((ni.signum() >= 0 ? "Net income " : "Net loss ") + Fmt.peso(ni.abs())
                    + "   ·   Balance sheet total Dr " + Fmt.peso(current.grand()[Accounting.B_DR])
                    + " = Cr " + Fmt.peso(current.grand()[Accounting.B_CR]) + "   ·   Ending difference "
                    + Fmt.peso(current.grand()[Accounting.B_DR].subtract(current.grand()[Accounting.B_CR]).abs()));
        }
        grid.done();
    }

    // ----------------------------------------------------------------------- CSV

    private static String csv(String s) {
        return s.contains(",") || s.contains("\"") || s.contains("\n") ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }

    private static String plain(BigDecimal v) {
        return v.signum() == 0 ? "" : v.setScale(2).toPlainString();
    }

    private void downloadCsv() {
        try {
            refresh();
        } catch (DbException e) {
            Theme.error(this, e);
            return;
        }
        if (current.rows().isEmpty()) {
            JOptionPane.showMessageDialog(this, "There is nothing to export yet.", "Download CSV",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("TALA-12-columnar.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }
        if (file.exists() && JOptionPane.showConfirmDialog(this, file.getName() + " already exists. Replace it?",
                "Download CSV", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }

        List<String> lines = new ArrayList<>();
        StringBuilder head1 = new StringBuilder("Code,Account");
        for (int i = 0; i < 12; i++) {
            head1.append(',').append(csv(GROUPS[i / 2] + (i % 2 == 0 ? " Dr" : " Cr")));
        }
        lines.add(head1.toString());
        for (Accounting.WsRow r : current.rows()) {
            StringBuilder sb = new StringBuilder().append(r.account().code()).append(',').append(csv(r.account().name()));
            for (BigDecimal v : r.values()) {
                sb.append(',').append(plain(v));
            }
            lines.add(sb.toString());
        }
        String[] labels = {"TOTAL", "NET INCOME", "OWNER'S EQUITY", "GRAND TOTAL"};
        BigDecimal[][] sums = {current.total(), current.netIncomeRow(), current.ownersEquityRow(), current.grand()};
        for (int k = 0; k < labels.length; k++) {
            StringBuilder sb = new StringBuilder().append(',').append(csv(labels[k]));
            for (int i = 0; i < sums[k].length; i++) {
                sb.append(',').append(plain(sums[k][i]));
            }
            if (k == labels.length - 1) { // GRAND TOTAL: the Balance Sheet columns end in 0.00, same as on screen
                String[] end = balanceSheetEnding(sums[k]);
                String[] parts = sb.toString().split(",", -1);
                parts[Accounting.B_DR + 2] = end[0];
                parts[Accounting.B_CR + 2] = end[1];
                sb = new StringBuilder(String.join(",", parts));
            }
            lines.add(sb.toString());
        }
        try {
            Files.write(file.toPath(), (String.join("\r\n", lines) + "\r\n").getBytes(StandardCharsets.UTF_8));
            JOptionPane.showMessageDialog(this, "Saved " + file.getAbsolutePath(), "Download CSV",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            Theme.error(this, new IOException("Could not save the file: " + e.getMessage(), e));
        }
    }
}
