package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.math.BigDecimal;
import java.util.List;

/*
 * ==============================================================
 *  LedgerPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: General Ledger screen: one ledger per used account with running balance and ending balance.
 *  USED BY: MainFrame
 * ==============================================================
 */

public final class LedgerPage extends Page {

    /** One entry in the account drop-down; account == null means "All accounts". */
    private record Choice(Account account) {
        @Override
        public String toString() {
            return account == null ? "All accounts" : account.label();
        }
    }

    private final JComboBox<Choice> picker = new JComboBox<>();
    private final JPanel stack = new JPanel();
    private boolean loading;

    public LedgerPage() {
        super("General Ledger", "General Ledger",
                "One ledger per account you have used: every transaction on that account, its running balance, total and ending balance.");

        JPanel filter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filter.setOpaque(false);
        filter.add(Theme.label("Account", Font.BOLD, 12, Theme.MUTED));
        picker.setFont(Theme.font(Font.PLAIN, 13));
        picker.setPreferredSize(new Dimension(260, 34));
        picker.addActionListener(e -> {
            if (!loading) {
                guarded();
            }
        });
        filter.add(picker);
        Theme.Btn refresh = new Theme.Btn("Refresh", Theme.Kind.SECONDARY);
        refresh.addActionListener(e -> guarded());
        addAction(filter);
        addAction(refresh);

        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(stack, BorderLayout.NORTH);
        setContent(wrap, true);
    }

    private void guarded() {
        try {
            refresh();
        } catch (DbException e) {
            Theme.error(this, e);
        }
    }

    private static String side(BigDecimal signed) {
        return Fmt.peso(signed.abs()) + (signed.signum() < 0 ? " CR" : " DR");
    }

    @Override
    public void refresh() {
        List<Accounting.AccountLedger> ledgers = Accounting.ledgers(Repo.accounts(), Repo.entries());

        Choice previous = (Choice) picker.getSelectedItem();
        loading = true;
        try {
            DefaultComboBoxModel<Choice> model = new DefaultComboBoxModel<>();
            model.addElement(new Choice(null));
            Choice keep = model.getElementAt(0);
            for (Accounting.AccountLedger l : ledgers) {
                Choice c = new Choice(l.account());
                model.addElement(c);
                if (previous != null && previous.account() != null && previous.account().code() == l.account().code()) {
                    keep = c;
                }
            }
            picker.setModel(model);
            picker.setSelectedItem(keep);
        } finally {
            loading = false;
        }
        Choice selected = (Choice) picker.getSelectedItem();

        stack.removeAll();
        if (ledgers.isEmpty()) {
            Theme.Card empty = new Theme.Card();
            empty.setLayout(new BorderLayout());
            empty.add(Theme.label("No entries yet. Record a transaction under Journal Entry and its ledgers will appear here.",
                    Font.PLAIN, 13, Theme.MUTED));
            stack.add(empty);
        }
        for (Accounting.AccountLedger l : ledgers) {
            if (selected != null && selected.account() != null && selected.account().code() != l.account().code()) {
                continue;
            }
            stack.add(card(l));
            stack.add(Box.createVerticalStrut(16));
        }
        stack.revalidate();
        stack.repaint();
    }

    private JPanel card(Accounting.AccountLedger l) {
        Account a = l.account();
        Theme.Card card = new Theme.Card();
        card.setLayout(new BorderLayout(0, 12));
        card.setAlignmentX(LEFT_ALIGNMENT);

        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        JPanel titleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        titleRow.setOpaque(false);
        titleRow.setAlignmentX(LEFT_ALIGNMENT);
        titleRow.add(Theme.label(a.name(), Font.BOLD, 17, Theme.INK));
        if (l.abnormal()) {
            titleRow.add(Box.createHorizontalStrut(10));
            titleRow.add(new Theme.Pill("Abnormal balance", Theme.RED, Theme.RED_BG));
        }
        JLabel sub = Theme.label("Account " + a.code() + " · " + a.typeLabel()
                + " · Normal balance: " + (a.isDebitNormal() ? "Debit" : "Credit"), Font.PLAIN, 12, Theme.MUTED);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        sub.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
        head.add(titleRow);
        head.add(sub);
        card.add(head, BorderLayout.NORTH);

        Grid grid = new Grid("Date", "Description", "Ref", "Debit", "Credit", "Balance")
                .rightAlign(3, 4, 5).widths(90, 260, 100, 130, 130, 150);
        for (Accounting.LedgerLine line : l.lines()) {
            grid.add(Grid.NORMAL, Fmt.monthDay(line.date()), line.description(), line.reference(),
                    line.debit().signum() == 0 ? "" : Fmt.peso(line.debit()),
                    line.credit().signum() == 0 ? "" : Fmt.peso(line.credit()),
                    side(line.balance()));
        }
        grid.add(Grid.TOTAL, "Total / ending", "", "", Fmt.peso(l.totalDebit()), Fmt.peso(l.totalCredit()), side(l.balance()));
        JTable table = grid.table(false);
        card.add(Grid.plain(table), BorderLayout.CENTER);
        return card;
    }
}
