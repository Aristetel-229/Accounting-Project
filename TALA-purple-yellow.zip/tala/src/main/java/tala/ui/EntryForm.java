package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/*
 * ==============================================================
 *  EntryForm.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: The form for recording a transaction (date, amount, description, debit account, credit account). Checks the input before posting.
 *  USED BY: JournalEntryPage, WorksheetPage
 * ==============================================================
 */

/**
 * The "record a transaction" card: date, reference, amount, description, debit and credit account,
 * a live preview and the Validate and Post button. Used on the Journal Entry screen and in the Add Adjustment dialog.
 */
public class EntryForm extends Theme.Card {

    private final boolean adjustment;
    private final Theme.HintField date = new Theme.HintField("YYYYMMDD");
    private final Theme.HintField reference = new Theme.HintField("");
    private final Theme.HintField amount = new Theme.HintField("0.00");
    private final Theme.HintField description = new Theme.HintField("What was this transaction for?");
    private final JComboBox<Account> debit = new JComboBox<>();
    private final JComboBox<Account> credit = new JComboBox<>();
    private final JLabel preview = new JLabel();
    private final JLabel message = new JLabel();
    private final Theme.Btn post;
    private Runnable onPosted = () -> { };
    private boolean loading;
    private JComponent problemField;

    public EntryForm(boolean adjustment) {
        this.adjustment = adjustment;
        setLayout(new GridBagLayout());

        date.setText(Fmt.compact(LocalDate.now()));
        reference.setText(newReference());
        reference.setEditable(false);
        reference.setBackground(new Color(0xF8F4FF));
        for (JComboBox<Account> box : List.of(debit, credit)) {
            box.setFont(Theme.font(Font.PLAIN, 14));
            box.setPreferredSize(new Dimension(100, 36));
        }
        for (Theme.HintField f : List.of(date, reference, amount, description)) {
            f.setPreferredSize(new Dimension(100, 36));
        }

        add(block("Transaction date", "YYYYMMDD", date), cell(0, 0, 2));
        add(block("Reference number", null, reference), cell(2, 0, 2));
        add(block("Amount " + Fmt.PESO, null, amount), cell(4, 0, 2));
        add(block("Description", null, description), cell(0, 1, 6));
        add(block("Debit account", null, debit), cell(0, 2, 3));
        add(block("Credit account", null, credit), cell(3, 2, 3));

        JPanel strip = new JPanel(new BorderLayout());
        strip.setBackground(new Color(0xF8F4FF));
        strip.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                new LineBorder(Theme.LINE, 1, true), new EmptyBorder(11, 14, 11, 14)));
        preview.setFont(Theme.font(Font.PLAIN, 14));
        preview.setForeground(Theme.INK);
        strip.add(preview, BorderLayout.CENTER);
        add(strip, cell(0, 3, 6));

        post = new Theme.Btn(adjustment ? "Validate and Post Adjustment" : "Validate and Post Entry", Theme.Kind.PRIMARY);
        post.addActionListener(e -> post());
        message.setFont(Theme.font(Font.PLAIN, 13));
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(message, BorderLayout.CENTER);
        bottom.add(post, BorderLayout.EAST);
        GridBagConstraints last = cell(0, 4, 6);
        last.insets = new Insets(0, 0, 0, 0);
        add(bottom, last);

        DocumentListener refresh = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateUi();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateUi();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateUi();
            }
        };
        date.getDocument().addDocumentListener(refresh);
        amount.getDocument().addDocumentListener(refresh);
        description.getDocument().addDocumentListener(refresh);
        debit.addActionListener(e -> updateUi());
        credit.addActionListener(e -> updateUi());
        updateUi();
    }

    /** Called after an entry has been posted successfully. */
    public void setOnPosted(Runnable r) {
        onPosted = r;
    }

    private static GridBagConstraints cell(int x, int y, int width) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = x;
        g.gridy = y;
        g.gridwidth = width;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(0, 0, 16, x + width >= 6 ? 0 : 16);
        return g;
    }

    private static JPanel block(String title, String hint, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        top.setOpaque(false);
        top.add(Theme.label(title, Font.BOLD, 12, Theme.MUTED));
        if (hint != null) {
            JLabel h = Theme.label(hint, Font.PLAIN, 11, Theme.FAINT);
            h.setBorder(new EmptyBorder(0, 6, 0, 0));
            top.add(h);
        }
        p.add(top, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private String newReference() {
        return (adjustment ? "AJ" : "JE") + String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }

    /** Reloads the account lists (keeps the current choices where possible). Call when the screen is shown. */
    public void reload() {
        List<Account> accounts = Repo.accounts().stream().filter(Account::active).toList();
        loading = true;
        try {
            fill(debit, accounts, 0);
            fill(credit, accounts, 1);
        } finally {
            loading = false;
        }
        updateUi();
    }

    private void fill(JComboBox<Account> box, List<Account> accounts, int defaultIndex) {
        Account previous = (Account) box.getSelectedItem();
        box.setModel(new DefaultComboBoxModel<>(accounts.toArray(new Account[0])));
        int pick = Math.min(defaultIndex, accounts.size() - 1);
        if (previous != null) {
            for (int i = 0; i < accounts.size(); i++) {
                if (accounts.get(i).code() == previous.code()) {
                    pick = i;
                }
            }
        }
        if (pick >= 0) {
            box.setSelectedIndex(pick);
        }
    }

    /** The first thing wrong with the form, or null when it can be posted. Also remembers which field to focus. */
    private String problem() {
        problemField = null;
        try {
            Validate.date(date.getText());
        } catch (IllegalArgumentException e) {
            problemField = date;
            return e.getMessage();
        }
        try {
            Validate.amount(amount.getText());
        } catch (IllegalArgumentException e) {
            problemField = amount;
            return e.getMessage();
        }
        Account dr = (Account) debit.getSelectedItem();
        Account cr = (Account) credit.getSelectedItem();
        if (dr == null || cr == null) {
            problemField = debit;
            return "Choose a debit and a credit account";
        }
        if (dr.code() == cr.code()) {
            problemField = credit;
            return "The debit and credit accounts must be different";
        }
        String d = description.getText().trim();
        if (d.isEmpty()) {
            problemField = description;
            return "Add a short description";
        }
        if (d.length() > 255) {
            problemField = description;
            return "The description is too long (255 characters at most)";
        }
        return null;
    }

    private void updateUi() {
        if (loading) {
            return;
        }
        BigDecimal amt;
        try {
            amt = Validate.amount(amount.getText());
        } catch (IllegalArgumentException e) {
            amt = BigDecimal.ZERO.setScale(2);
        }
        Account dr = (Account) debit.getSelectedItem();
        Account cr = (Account) credit.getSelectedItem();
        String drName = dr == null ? "-" : Theme.esc(dr.name());
        String crName = cr == null ? "-" : Theme.esc(cr.name());
        String money = Fmt.peso(amt);
        preview.setText("<html><b style='color:#1E8A5B'>DEBIT</b>&nbsp;&nbsp;" + drName + " · " + money
                + "&nbsp;&nbsp;&nbsp;→&nbsp;&nbsp;&nbsp;<b style='color:#C23B3B'>CREDIT</b>&nbsp;&nbsp;"
                + crName + " · " + money + "</html>");

        String p = problem();
        if (p == null) {
            message.setText("<html><b>✓ Ready to post</b><br><span style='color:#6B7385'>Debits equal credits.</span></html>");
            message.setForeground(Theme.GREEN);
        } else {
            message.setText("<html>" + Theme.esc(p) + "<br><span style='color:#A2A9B8'>Debits must equal credits.</span></html>");
            message.setForeground(Theme.MUTED);
        }
    }

    private void post() {
        String p = problem();
        if (p != null) {
            message.setText("<html><b>" + Theme.esc(p) + "</b></html>");
            message.setForeground(Theme.RED);
            if (problemField != null) {
                problemField.requestFocusInWindow();
            }
            return;
        }
        try {
            LocalDate d = Validate.date(date.getText());
            BigDecimal a = Validate.amount(amount.getText());
            String ref = reference.getText();
            for (int tries = 0; tries < 20 && Repo.referenceExists(ref); tries++) {
                ref = newReference();
            }
            Account dr = (Account) debit.getSelectedItem();
            Account cr = (Account) credit.getSelectedItem();
            Repo.insert(new Entry(0, d, ref, description.getText().trim(), dr.code(), cr.code(), a, adjustment));

            amount.setText("");
            description.setText("");
            reference.setText(newReference());
            updateUi();
            message.setText("<html><b>✓ Posted " + Theme.esc(ref) + "</b></html>");
            message.setForeground(Theme.GREEN);
            onPosted.run();
        } catch (DbException ex) {
            Theme.error(this, ex);
        }
    }
}
