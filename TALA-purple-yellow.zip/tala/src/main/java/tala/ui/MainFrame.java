package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;

/*
 * ==============================================================
 *  MainFrame.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: The main window: the purple top bar with the tabs (Dashboard, Journal Entry, ...) and the page shown below it.
 *  USED BY: Main
 * ==============================================================
 */

/** The application window: a top navigation bar and one page at a time. */
public final class MainFrame extends JFrame {

    public static final String DASHBOARD = "Dashboard";
    public static final String JOURNAL_ENTRY = "Journal Entry";
    public static final String GENERAL_JOURNAL = "General Journal";
    public static final String CHART = "Chart of Accounts";
    public static final String LEDGER = "General Ledger";
    public static final String WORKSHEET = "12 Columnar";

    private final CardLayout cards = new CardLayout();
    private final JPanel center = new JPanel(cards);
    private final Map<String, Page> pages = new LinkedHashMap<>();
    private final Map<String, NavTab> tabs = new LinkedHashMap<>();
    private final Theme.Pill statusPill = new Theme.Pill("", Theme.GREEN, Theme.GREEN_BG);
    private String currentPage = DASHBOARD;

    public MainFrame() {
        super("TALA - Student Edition");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Theme.PURPLE_DARK);
        setLayout(new BorderLayout());

        pages.put(DASHBOARD, new DashboardPage());
        pages.put(JOURNAL_ENTRY, new JournalEntryPage());
        pages.put(GENERAL_JOURNAL, new GeneralJournalPage());
        pages.put(CHART, new ChartPage());
        pages.put(LEDGER, new LedgerPage());
        pages.put(WORKSHEET, new WorksheetPage());

        add(buildNav(), BorderLayout.NORTH);
        center.setOpaque(false); // each page paints its own gradient
        for (Map.Entry<String, Page> e : pages.entrySet()) {
            center.add(e.getValue(), e.getKey());
        }
        add(center, BorderLayout.CENTER);

        Status.onChange(connected -> updateStatus());
        updateStatus();

        setMinimumSize(new Dimension(1000, 640));
        setSize(1240, 800);
        setLocationRelativeTo(null);
        showPage(DASHBOARD);
    }

    public void showPage(String name) {
        currentPage = name;
        cards.show(center, name);
        for (Map.Entry<String, NavTab> t : tabs.entrySet()) {
            t.getValue().setActive(t.getKey().equals(name));
        }
        try {
            pages.get(name).refresh();
        } catch (DbException e) {
            Theme.error(this, e);
        }
    }

    private JPanel buildNav() {
        JPanel nav = new NavBar();
        nav.setPreferredSize(new Dimension(100, 60));
        nav.setBorder(new EmptyBorder(0, 24, 0, 24));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        left.setOpaque(false);
        left.add(new Logo());
        for (String name : pages.keySet()) {
            NavTab tab = new NavTab(name);
            tab.addActionListener(e -> showPage(name));
            tabs.put(name, tab);
            left.add(tab);
        }

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        statusPill.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        statusPill.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                changeConnection();
            }
        });
        Theme.Pill edition = new Theme.Pill("Student Edition", Theme.PURPLE_DARK, Theme.YELLOW);
        right.add(statusPill);
        right.add(edition);

        // centre the contents vertically inside the 60px bar
        JPanel leftWrap = new JPanel(new java.awt.GridBagLayout());
        leftWrap.setOpaque(false);
        leftWrap.add(left);
        JPanel rightWrap = new JPanel(new java.awt.GridBagLayout());
        rightWrap.setOpaque(false);
        rightWrap.add(right);
        nav.add(leftWrap, BorderLayout.WEST);
        nav.add(rightWrap, BorderLayout.EAST);
        return nav;
    }

    private void changeConnection() {
        if (Status.demo()) {
            return;
        }
        if (DbSettingsDialog.connectLoop(this, true)) {
            showPage(currentPage);
        }
    }

    private void updateStatus() {
        if (Status.demo()) {
            statusPill.setText("Demo data - nothing is saved");
            statusPill.setColors(new Color(0x7A5B00), new Color(0xFFF1C9));
        } else if (Status.connected()) {
            statusPill.setText("● Connected to MySQL");
            statusPill.setColors(Theme.GREEN, Theme.GREEN_BG);
        } else {
            statusPill.setText("● Disconnected - click to fix");
            statusPill.setColors(Theme.RED, Theme.RED_BG);
        }
        statusPill.revalidate();
        statusPill.repaint();
    }

    // ------------------------------------------------------------- nav widgets

    /** The top bar: a deep-purple to violet gradient with a thin yellow line along the bottom. */
    private static final class NavBar extends JPanel {
        NavBar() {
            super(new BorderLayout());
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setPaint(new GradientPaint(0, 0, Theme.PURPLE_DARK, getWidth(), 0, Theme.PURPLE));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setPaint(new GradientPaint(0, 0, Theme.GOLD, getWidth(), 0, Theme.YELLOW));
            g2.fillRect(0, getHeight() - 2, getWidth(), 2);
            g2.dispose();
        }
    }

    private static final class Logo extends JPanel {
        Logo() {
            setOpaque(false);
            setPreferredSize(new Dimension(108, 40));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int size = 30;
            int y = (getHeight() - size) / 2;
            g2.setPaint(new GradientPaint(0, y, Theme.YELLOW_SOFT, size, y + size, Theme.GOLD));
            g2.fillRoundRect(0, y, size, size, 9, 9);
            g2.setColor(Theme.PURPLE_DARK);
            g2.setFont(Theme.font(Font.BOLD, 17));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString("T", (size - fm.stringWidth("T")) / 2, y + (size - fm.getHeight()) / 2 + fm.getAscent());
            g2.setColor(Color.WHITE);
            g2.setFont(Theme.font(Font.BOLD, 18));
            fm = g2.getFontMetrics();
            g2.drawString("TALA", size + 10, y + (size - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }

    private static final class NavTab extends JButton {
        private boolean active;
        private boolean hover;

        NavTab(String text) {
            super(text);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setFont(Theme.font(Font.BOLD, 13));
            setBorder(new EmptyBorder(0, 14, 0, 14));
            setPreferredSize(new Dimension(getFontMetrics(getFont()).stringWidth(text) + 32, 60));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        void setActive(boolean a) {
            active = a;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(getFont());
            g2.setColor(active ? Color.WHITE : hover ? new Color(0xF0E8FF) : new Color(0xBFAEEA));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                    (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            if (active) {
                g2.setPaint(new GradientPaint(8, 0, Theme.YELLOW, getWidth() - 8, 0, Theme.GOLD));
                g2.fillRoundRect(8, getHeight() - 4, getWidth() - 16, 4, 4, 4);
            }
            g2.dispose();
        }
    }
}
