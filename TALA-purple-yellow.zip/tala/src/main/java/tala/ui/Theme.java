package tala.ui;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/*
 * ==============================================================
 *  Theme.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: ALL colours, fonts and the custom-drawn parts (cards, buttons, pills) live here. Want a different colour? Change it in this file only.
 *  USED BY: every screen
 * ==============================================================
 */

/** Colours, fonts and the few custom-painted widgets (cards, buttons, pills) shared by every screen. */
public final class Theme {

    // ---- Purple + yellow palette (change a colour here and the whole app follows) ----
    // Page background gradient: soft lavender (top-left) fading to soft cream-yellow (bottom-right)
    public static final Color BG = new Color(0xF4EFFF);
    public static final Color BG_END = new Color(0xFFF6D8);
    public static final Color CARD = Color.WHITE;
    public static final Color CARD_END = new Color(0xFAF6FF);
    public static final Color LINE = new Color(0xE3D9F7);
    public static final Color INK = new Color(0x241549);
    public static final Color MUTED = new Color(0x6E6290);
    public static final Color FAINT = new Color(0xAEA3C9);

    // Purples (dark -> light)
    public static final Color PURPLE_DARK = new Color(0x2B1062);
    public static final Color PURPLE = new Color(0x5B2BC0);
    public static final Color PURPLE_LIGHT = new Color(0x8B5CF6);

    // Yellows (deep -> light)
    public static final Color GOLD = new Color(0xF5B800);
    public static final Color YELLOW = new Color(0xFFD83D);
    public static final Color YELLOW_SOFT = new Color(0xFFF1B8);

    public static final Color GREEN = new Color(0x1E8A5B);
    public static final Color GREEN_BG = new Color(0xE6F5EE);
    public static final Color RED = new Color(0xC23B3B);
    public static final Color RED_BG = new Color(0xFBEAEA);
    public static final Color SELECT = new Color(0xE6DAFF);
    public static final Color HEAD = new Color(0xF1EAFF);
    public static final Color STRIPE = new Color(0xFAF7FF);

    private static final String FAMILY = pickFamily();

    private Theme() {
    }

    private static String pickFamily() {
        String[] wanted = {"Segoe UI", "SF Pro Text", "Helvetica Neue", "Inter", "Noto Sans", "DejaVu Sans"};
        String[] have = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (String w : wanted) {
            for (String h : have) {
                if (h.equals(w)) {
                    return w;
                }
            }
        }
        return Font.SANS_SERIF;
    }

    public static Font font(int style, float size) {
        return new Font(FAMILY, Font.PLAIN, 12).deriveFont(style, size);
    }

    public static JLabel label(String text, int style, float size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    public static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    public static void error(Component parent, Throwable t) {
        String msg = t.getMessage() == null ? t.toString() : t.getMessage();
        JOptionPane.showMessageDialog(parent, msg, "TALA", JOptionPane.ERROR_MESSAGE);
    }

    private static void smooth(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    /** Fills a rounded shape with a two-colour gradient (vertical = top to bottom, otherwise left to right). */
    static void gradientRound(Graphics2D g2, int w, int h, int arc, Color from, Color to, boolean vertical) {
        g2.setPaint(vertical ? new GradientPaint(0, 0, from, 0, h, to) : new GradientPaint(0, 0, from, w, 0, to));
        g2.fillRoundRect(0, 0, w - 1, h - 1, arc, arc);
    }

    /** Paints the page background: a diagonal gradient from lavender to cream. */
    public static void paintBackdrop(Graphics g, int w, int h) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setPaint(new GradientPaint(0, 0, BG, w, h, BG_END));
        g2.fillRect(0, 0, w, h);
        g2.dispose();
    }

    // ---------------------------------------------------------------------- card

    /** Rounded panel: white fading to a hint of lavender, with a thin purple-grey border. */
    public static class Card extends JPanel {
        public Card() {
            setOpaque(false);
            setBorder(new EmptyBorder(16, 18, 16, 18));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            smooth(g2);
            gradientRound(g2, getWidth(), getHeight(), 14, CARD, CARD_END, true);
            g2.setColor(LINE);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // -------------------------------------------------------------------- button

    /** PRIMARY = purple gradient, ACCENT = yellow gradient, SECONDARY = outlined, DANGER = red outline. */
    public enum Kind { PRIMARY, ACCENT, SECONDARY, DANGER }

    public static class Btn extends JButton {
        private final Kind kind;
        private boolean hover;

        public Btn(String text, Kind kind) {
            super(text);
            this.kind = kind;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setFont(font(Font.BOLD, 13));
            setBorder(new EmptyBorder(9, 16, 9, 16));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            smooth(g2);
            boolean on = isEnabled();
            Color fill = null, text, border = null;
            Color gradFrom = null, gradTo = null;
            switch (kind) {
                case PRIMARY -> {
                    gradFrom = on ? (hover ? PURPLE_LIGHT : PURPLE) : new Color(0xC9C0E0);
                    gradTo = on ? (hover ? PURPLE : PURPLE_DARK) : new Color(0xB5AAD3);
                    text = Color.WHITE;
                }
                case ACCENT -> {
                    gradFrom = on ? (hover ? YELLOW_SOFT : YELLOW) : new Color(0xEDE6C8);
                    gradTo = on ? (hover ? YELLOW : GOLD) : new Color(0xE2D9B0);
                    text = PURPLE_DARK;
                }
                case DANGER -> {
                    fill = hover && on ? RED_BG : CARD;
                    text = on ? RED : FAINT;
                    border = on ? new Color(0xE6B8B8) : LINE;
                }
                default -> {
                    fill = hover && on ? HEAD : CARD;
                    text = on ? PURPLE : FAINT;
                    border = on ? new Color(0xCDBDF2) : LINE;
                }
            }
            if (gradFrom != null) {
                gradientRound(g2, getWidth(), getHeight(), 10, gradFrom, gradTo, true);
            } else {
                g2.setColor(fill);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            }
            if (border != null) {
                g2.setColor(border);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            }
            g2.setColor(text);
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(getText())) / 2;
            int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(getText(), x, y);
            g2.dispose();
        }
    }

    // ---------------------------------------------------------------- text field

    /** Text field with grey placeholder text. */
    public static class HintField extends JTextField {
        private final String hint;

        public HintField(String hint) {
            this.hint = hint;
            setFont(font(Font.PLAIN, 14));
            setForeground(INK);
            setCaretColor(INK);
            setBorder(BorderFactory.createCompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(7, 10, 7, 10)));
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty() && !isFocusOwner() && hint != null) {
                Graphics2D g2 = (Graphics2D) g.create();
                smooth(g2);
                g2.setColor(FAINT);
                g2.setFont(getFont());
                Insets in = getInsets();
                FontMetrics fm = g2.getFontMetrics();
                int y = in.top + (getHeight() - in.top - in.bottom - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(hint, in.left, y);
                g2.dispose();
            }
        }
    }

    // ---------------------------------------------------------------------- pill

    /** Small rounded label, e.g. "Abnormal balance". */
    public static class Pill extends JLabel {
        private Color background;

        public Pill(String text, Color fg, Color bg) {
            super(text);
            this.background = bg;
            setForeground(fg);
            setFont(font(Font.BOLD, 11));
            setOpaque(false);
            setBorder(new EmptyBorder(3, 10, 3, 10));
        }

        public void setColors(Color fg, Color bg) {
            setForeground(fg);
            background = bg;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            smooth(g2);
            g2.setColor(background);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // -------------------------------------------------------------- scroll body

    /** Panel for a JScrollPane that follows the viewport width, so content never needs a sideways scrollbar. */
    public static class ScrollBody extends JPanel implements Scrollable {
        public ScrollBody() {
            super(new java.awt.BorderLayout());
            setOpaque(false); // let the page gradient show through
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 24;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return Math.max(60, visibleRect.height - 60);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return getParent() instanceof JViewport vp && vp.getHeight() > getPreferredSize().height;
        }
    }
}
