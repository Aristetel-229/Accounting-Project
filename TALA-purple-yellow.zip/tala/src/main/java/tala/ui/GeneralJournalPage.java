package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * ==============================================================
 *  GeneralJournalPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: General Journal screen: every entry in date order with particulars, post reference, debit and credit.
 *  USED BY: MainFrame
 * ==============================================================
 */

public final class GeneralJournalPage extends Page {

    private final Grid grid = new Grid("Date", "Particulars", "Post Ref", "Debit", "Credit")
            .rightAlign(3, 4).indentColumn(1).widths(110, 380, 90, 140, 140);
    private final JLabel summary = Theme.label("", Font.PLAIN, 13, Theme.MUTED);

    public GeneralJournalPage() {
        super("General Journal", "General Journal",
                "Every entry in date order: date, particulars, post reference, debit and credit. Only accounts you have used appear.");

        Theme.Btn refresh = new Theme.Btn("Refresh", Theme.Kind.SECONDARY);
        refresh.addActionListener(e -> {
            try {
                refresh();
            } catch (DbException ex) {
                Theme.error(this, ex);
            }
        });
        addAction(refresh);

        JTable table = grid.table(false);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Theme.LINE));
        sp.getViewport().setBackground(Color.WHITE);

        Theme.Card card = new Theme.Card();
        card.setLayout(new BorderLayout(0, 12));
        card.add(sp, BorderLayout.CENTER);
        card.add(summary, BorderLayout.SOUTH);
        setContent(card, false);
    }

    @Override
    public void refresh() {
        Map<Integer, Account> accounts = new HashMap<>();
        for (Account a : Repo.accounts()) {
            accounts.put(a.code(), a);
        }
        List<Entry> entries = Repo.entries();

        grid.clear();
        BigDecimal total = BigDecimal.ZERO.setScale(2);
        int year = -1;
        for (Entry e : entries) {
            if (e.date().getYear() != year) {
                year = e.date().getYear();
                grid.add(Grid.SECTION, String.valueOf(year));
            }
            Account dr = accounts.get(e.debitCode());
            Account cr = accounts.get(e.creditCode());
            grid.add(Grid.NORMAL, Fmt.monthDay(e.date()), dr.name(), String.valueOf(dr.code()), Fmt.peso(e.amount()), "");
            grid.add(Grid.INDENT, "", cr.name(), String.valueOf(cr.code()), "", Fmt.peso(e.amount()));
            grid.add(Grid.NOTE, "", e.description() + " · " + e.reference());
            total = total.add(e.amount());
        }
        if (entries.isEmpty()) {
            grid.add(Grid.NOTE, "", "No entries yet. Record a transaction under Journal Entry.");
        } else {
            grid.add(Grid.TOTAL, "", "TOTAL", "", Fmt.peso(total), Fmt.peso(total));
        }
        grid.done();

        summary.setText(entries.size() + (entries.size() == 1 ? " entry" : " entries")
                + "   ·   Total debit " + Fmt.peso(total)
                + "   ·   Total credit " + Fmt.peso(total)
                + "   ·   In balance ✓");
    }
}
