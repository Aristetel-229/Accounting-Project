package tala.ui;

import tala.data.*;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;

/*
 * ==============================================================
 *  DbSettingsDialog.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: The small window that asks for the MySQL host, port, database, user and password.
 *  USED BY: Main, MainFrame
 * ==============================================================
 */

/** Asks for the MySQL connection details and retries until the database is reachable or the user gives up. */
public final class DbSettingsDialog {

    private DbSettingsDialog() {
    }

    /**
     * Connects (creating database and tables on first use). If askFirst is false the saved settings are tried
     * silently first. Returns false if the user cancels.
     */
    public static boolean connectLoop(Component parent, boolean askFirst) {
        Throwable error = null;
        boolean ask = askFirst;
        while (true) {
            if (ask && !prompt(parent, error)) {
                return false;
            }
            try {
                Db.initialize();
                Status.set(true);
                return true;
            } catch (SQLException | RuntimeException e) {
                error = e;
                ask = true;
            }
        }
    }

    private static boolean prompt(Component parent, Throwable error) {
        JTextField host = new JTextField(Db.host, 18);
        JTextField port = new JTextField(Db.port, 18);
        JTextField database = new JTextField(Db.database, 18);
        JTextField user = new JTextField(Db.user, 18);
        JPasswordField password = new JPasswordField(Db.password, 18);

        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = 0;
        g.gridwidth = 2;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(0, 0, 10, 0);
        if (error != null) {
            String msg = error.getMessage() == null ? error.toString() : error.getMessage();
            p.add(new JLabel("<html><div style='width:360px'><b>Could not connect to MySQL.</b><br>"
                    + Theme.esc(msg) + "<br><br>Check that the MySQL server is running, that the details below are right "
                    + "and that the mysql-connector-j .jar is in the lib folder.</div></html>"), g);
        } else {
            p.add(new JLabel("<html><div style='width:360px'>Enter the connection details of your MySQL server. "
                    + "The database and its tables are created for you if they do not exist yet.</div></html>"), g);
        }
        g.gridwidth = 1;
        g.insets = new Insets(3, 0, 3, 10);
        String[] labels = {"Host", "Port", "Database", "User", "Password"};
        Component[] fields = {host, port, database, user, password};
        for (int i = 0; i < labels.length; i++) {
            g.gridy = i + 1;
            g.gridx = 0;
            p.add(new JLabel(labels[i]), g);
            g.gridx = 1;
            p.add(fields[i], g);
        }

        Object[] options = {"Save and connect", parent == null ? "Quit" : "Cancel"};
        int choice = JOptionPane.showOptionDialog(parent, p, "TALA - database connection",
                JOptionPane.DEFAULT_OPTION, error != null ? JOptionPane.WARNING_MESSAGE : JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);
        if (choice != 0) {
            return false;
        }
        Db.host = host.getText().trim();
        Db.port = port.getText().trim();
        Db.database = database.getText().trim();
        Db.user = user.getText().trim();
        Db.password = new String(password.getPassword());
        Db.save();
        return true;
    }
}
