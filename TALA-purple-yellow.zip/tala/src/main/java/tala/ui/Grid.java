package tala.ui;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/*
 * ==============================================================
 *  Grid.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: The table used by every screen: purple gradient header, striped rows, yellow total rows.
 *  USED BY: all the *Page files
 * ==============================================================
 */

/**
 * A read-only table model made of text cells, plus the styling every TALA table shares.
 * Each row has a style: normal, total (bold, tinted), note (small grey italics), section (bold, tinted) or indent.
 */
public final class Grid extends AbstractTableModel {

    public static final int NORMAL = 0, TOTAL = 1, NOTE = 2, SECTION = 3, INDENT = 4;

    private final String[] columns;
    private final Set<Integer> rightAligned = new HashSet<>();
    private final List<String[]> rows = new ArrayList<>();
    private final List<Integer> styles = new ArrayList<>();
    private int indentColumn = -1;
    private int[] widths = new int[0];

    public Grid(String... columns) {
        this.columns = columns;
    }

    public Grid rightAlign(int... cols) {
        for (int c : cols) {
            rightAligned.add(c);
        }
        return this;
    }

    /** Column whose text is pushed in for INDENT and NOTE rows. */
    public Grid indentColumn(int col) {
        indentColumn = col;
        return this;
    }

    public Grid widths(int... w) {
        widths = w;
        return this;
    }

    public void clear() {
        rows.clear();
        styles.clear();
    }

    public void add(int style, String... cells) {
        String[] row = new String[columns.length];
        for (int i = 0; i < row.length; i++) {
            row[i] = i < cells.length && cells[i] != null ? cells[i] : "";
        }
        rows.add(row);
        styles.add(style);
    }

    /** Call after add() / clear() so the table redraws. */
    public void done() {
        fireTableDataChanged();
    }

    public int style(int row) {
        return styles.get(row);
    }

    @Override
    public int getRowCount() {
        return rows.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int c) {
        return columns[c];
    }

    @Override
    public Object getValueAt(int r, int c) {
        return rows.get(r)[c];
    }

    // ------------------------------------------------------------------- styling

    public JTable table() {
        return table(true);
    }

    public JTable table(boolean selectable) {
        JTable t = new JTable(this);
        t.setRowHeight(30);
        t.setFont(Theme.font(Font.PLAIN, 13));
        t.setBackground(Color.WHITE);
        t.setForeground(Theme.INK);
        t.setShowVerticalLines(false);
        t.setShowHorizontalLines(true);
        t.setGridColor(new Color(0xEFE8FB));
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setFillsViewportHeight(true);
        t.setSelectionBackground(Theme.SELECT);
        t.setSelectionForeground(Theme.INK);
        t.setRowSelectionAllowed(selectable);
        t.setFocusable(selectable);
        t.setDefaultRenderer(Object.class, new CellRenderer());
        t.getTableHeader().setReorderingAllowed(false);
        // Header cells: purple gradient (top to bottom) with white text and a thin yellow line underneath
        t.getTableHeader().setDefaultRenderer((tbl, value, sel, foc, row, col) -> {
            String text = value == null ? "" : value.toString();
            JLabel l = new JLabel(text) {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setPaint(new GradientPaint(0, 0, Theme.PURPLE_LIGHT, 0, getHeight(), Theme.PURPLE));
                    g2.fillRect(0, 0, getWidth(), getHeight());
                    g2.setColor(Theme.YELLOW);
                    g2.fillRect(0, getHeight() - 2, getWidth(), 2);
                    g2.dispose();
                    super.paintComponent(g);
                }
            };
            l.setOpaque(false);
            l.setForeground(Color.WHITE);
            l.setFont(Theme.font(Font.BOLD, 11));
            l.setBorder(new EmptyBorder(0, 10, 0, 10));
            if (text.startsWith("<html>")) {
                l.setHorizontalAlignment(SwingConstants.CENTER);
            } else {
                l.setHorizontalAlignment(rightAligned.contains(col) ? SwingConstants.RIGHT : SwingConstants.LEFT);
            }
            Dimension d = l.getPreferredSize();
            l.setPreferredSize(new Dimension(d.width, Math.max(36, d.height + 8)));
            return l;
        });
        for (int i = 0; i < widths.length && i < t.getColumnCount(); i++) {
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
        return t;
    }

    /** Header + table stacked, for tables that sit inside a card instead of a scroll pane. */
    public static JPanel plain(JTable t) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(t.getTableHeader(), BorderLayout.NORTH);
        p.add(t, BorderLayout.CENTER);
        return p;
    }

    private final class CellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, v, sel, false, row, col);
            int style = style(row);
            Font font = Theme.font(Font.PLAIN, 13);
            Color fg = Theme.INK;
            Color bg = Color.WHITE;
            switch (style) {
                case TOTAL -> {              // totals: bold on soft yellow
                    font = Theme.font(Font.BOLD, 13);
                    bg = Theme.YELLOW_SOFT;
                    fg = Theme.PURPLE_DARK;
                }
                case SECTION -> {            // section headings: bold on lavender
                    font = Theme.font(Font.BOLD, 13);
                    bg = Theme.HEAD;
                    fg = Theme.PURPLE_DARK;
                }
                case NOTE -> {
                    font = Theme.font(Font.ITALIC, 12);
                    fg = Theme.MUTED;
                }
                default -> {
                    if (row % 2 == 1) {      // zebra stripes make long tables easier to read
                        bg = Theme.STRIPE;
                    }
                }
            }
            if (sel) {
                bg = Theme.SELECT;
            }
            setFont(font);
            setForeground(fg);
            setBackground(bg);
            setHorizontalAlignment(rightAligned.contains(col) ? SwingConstants.RIGHT : SwingConstants.LEFT);
            int left = col == indentColumn && (style == INDENT || style == NOTE) ? 32 : 10;
            setBorder(new EmptyBorder(0, left, 0, 10));
            return this;
        }
    }
}
