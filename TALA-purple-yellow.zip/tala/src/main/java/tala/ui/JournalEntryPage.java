package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * ==============================================================
 *  JournalEntryPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: Journal Entry screen: record a transaction and delete a single posted entry.
 *  USED BY: MainFrame
 * ==============================================================
 */

public final class JournalEntryPage extends Page {

    private final EntryForm form = new EntryForm(false);
    private final Grid grid = new Grid("Date", "Reference", "Description", "Debit", "Credit", "Amount")
            .rightAlign(5).widths(90, 100, 240, 170, 170, 110);
    private final JTable table = grid.table();
    private final JLabel count = Theme.label("", Font.PLAIN, 13, Theme.MUTED);
    private List<Entry> shown = List.of();

    public JournalEntryPage() {
        super("Journal Entry", "Journal Entry",
                "Record a transaction by choosing what is debited and what is credited. "
                        + "Made a mistake? Select the entry below and delete just that one.");
        form.setOnPosted(this::refreshTable);

        Theme.Card posted = new Theme.Card();
        posted.setLayout(new BorderLayout(0, 12));
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        JPanel title = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        title.setOpaque(false);
        title.add(Theme.label("Posted entries", Font.BOLD, 15, Theme.INK));
        count.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        title.add(count);
        Theme.Btn delete = new Theme.Btn("Delete Selected Entry", Theme.Kind.DANGER);
        delete.addActionListener(e -> deleteSelected());
        head.add(title, BorderLayout.WEST);
        head.add(delete, BorderLayout.EAST);
        posted.add(head, BorderLayout.NORTH);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Theme.LINE));
        sp.getViewport().setBackground(Color.WHITE);
        sp.setPreferredSize(new Dimension(300, 280));
        posted.add(sp, BorderLayout.CENTER);

        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setOpaque(false);
        content.add(form, BorderLayout.NORTH);
        content.add(posted, BorderLayout.CENTER);
        setContent(content, true);
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= shown.size()) {
            JOptionPane.showMessageDialog(this, "Select an entry in the list first.", "Delete entry",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Entry e = shown.get(row);
        int answer = JOptionPane.showConfirmDialog(this,
                "Delete " + e.reference() + " \"" + e.description() + "\" for " + Fmt.peso(e.amount()) + "?",
                "Delete entry", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (answer == JOptionPane.OK_OPTION) {
            try {
                Repo.delete(e.id());
                refreshTable();
            } catch (DbException ex) {
                Theme.error(this, ex);
            }
        }
    }

    private void refreshTable() {
        Map<Integer, String> names = new HashMap<>();
        for (Account a : Repo.accounts()) {
            names.put(a.code(), a.name());
        }
        shown = Repo.entries();
        grid.clear();
        for (Entry e : shown) {
            grid.add(Grid.NORMAL, Fmt.compact(e.date()), e.reference(), e.description(),
                    names.getOrDefault(e.debitCode(), "?"), names.getOrDefault(e.creditCode(), "?"),
                    Fmt.num(e.amount()));
        }
        grid.done();
        count.setText(shown.size() == 1 ? "1 entry" : shown.size() + " entries");
    }

    @Override
    public void refresh() {
        form.reload();
        refreshTable();
    }
}
