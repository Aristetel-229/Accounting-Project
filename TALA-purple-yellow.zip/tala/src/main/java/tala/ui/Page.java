package tala.ui;

import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;

/*
 * ==============================================================
 *  Page.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: The shared "template" of every screen: breadcrumb, big title, subtitle, buttons on the right, content below. Draws the lavender-to-yellow background.
 *  USED BY: all the *Page files
 * ==============================================================
 */

/** One screen: a breadcrumb, title (with action buttons on the right) and subtitle on top, content below. */
public abstract class Page extends JPanel {

    private final JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));

    protected Page(String crumb, String title, String subtitle) {
        super(new BorderLayout());

        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.setBorder(new EmptyBorder(26, 32, 16, 32));

        JLabel c = Theme.label("TALA / " + crumb.toUpperCase(), Font.BOLD, 11, Theme.MUTED);
        c.setAlignmentX(LEFT_ALIGNMENT);

        JLabel t = Theme.label(title, Font.BOLD, 26, Theme.INK);
        actions.setOpaque(false);
        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setOpaque(false);
        titleRow.setBorder(new EmptyBorder(4, 0, 4, 0));
        titleRow.setAlignmentX(LEFT_ALIGNMENT);
        titleRow.add(t, BorderLayout.WEST);
        titleRow.add(actions, BorderLayout.EAST);

        JLabel s = Theme.label(subtitle, Font.PLAIN, 13, Theme.MUTED);
        s.setAlignmentX(LEFT_ALIGNMENT);

        head.add(c);
        head.add(titleRow);
        head.add(s);
        add(head, BorderLayout.NORTH);
    }

    /** Draws the lavender-to-cream gradient behind everything on the page. */
    @Override
    protected void paintComponent(Graphics g) {
        Theme.paintBackdrop(g, getWidth(), getHeight());
    }

    protected void addAction(JComponent c) {
        actions.add(c);
    }

    /** scroll = true: the whole content scrolls. false: the content fills the page and manages its own scrolling. */
    protected void setContent(JComponent content, boolean scroll) {
        if (scroll) {
            Theme.ScrollBody body = new Theme.ScrollBody();
            body.setBorder(new EmptyBorder(0, 32, 28, 32));
            body.add(content, BorderLayout.CENTER);
            JScrollPane sp = new JScrollPane(body);
            sp.setBorder(null);
            sp.setOpaque(false);
            sp.getViewport().setOpaque(false);
            sp.getViewport().setScrollMode(javax.swing.JViewport.SIMPLE_SCROLL_MODE); // keeps the gradient clean while scrolling
            sp.getVerticalScrollBar().setUnitIncrement(24);
            add(sp, BorderLayout.CENTER);
        } else {
            JPanel pad = new JPanel(new BorderLayout());
            pad.setOpaque(false);
            pad.setBorder(new EmptyBorder(0, 32, 28, 32));
            pad.add(content, BorderLayout.CENTER);
            add(pad, BorderLayout.CENTER);
        }
    }

    /** Reload data from the database and redraw. Called every time the screen is shown. */
    public abstract void refresh();
}
