package tala.ui;

import tala.logic.*;
import tala.data.*;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/*
 * ==============================================================
 *  DashboardPage.java   [Screens (ui)]
 *  WHAT THIS FILE DOES: Dashboard screen: Assets = Liabilities + Owner's Equity, totals, net income and the latest entries.
 *  USED BY: MainFrame
 * ==============================================================
 */

public final class DashboardPage extends Page {

    private final JLabel assets = value();
    private final JLabel liabilities = value();
    private final JLabel equity = value();
    private final JLabel equation = new JLabel();
    private final JLabel tAssets = value(), tLiabilities = value(), tRevenue = value(), tExpenses = value(),
            tNet = value(), tCount = value();
    private final Grid recent = new Grid("Date", "Reference", "Description", "Amount").rightAlign(3).widths(110, 100, 220, 110);

    public DashboardPage() {
        super("Dashboard", "Dashboard", "Your books at a glance, based on all posted entries.");

        Theme.Btn refresh = new Theme.Btn("Refresh", Theme.Kind.SECONDARY);
        refresh.addActionListener(e -> guarded(this::refresh));
        Theme.Btn reset = new Theme.Btn("Reset Data", Theme.Kind.DANGER);
        reset.addActionListener(e -> guarded(this::resetData));
        addAction(refresh);
        addAction(reset);

        JPanel content = new JPanel(new GridBagLayout());
        content.setOpaque(false);

        // accounting equation:  ASSETS = LIABILITIES + OWNER'S EQUITY
        JPanel eq = new JPanel(new GridBagLayout());
        eq.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.BOTH;
        g.weighty = 1;
        g.gridy = 0;
        g.gridx = 0;
        g.weightx = 1;
        eq.add(equationCard("ASSETS", assets), g);
        g.gridx = 1;
        g.weightx = 0;
        eq.add(operator("="), g);
        g.gridx = 2;
        g.weightx = 1;
        eq.add(equationCard("LIABILITIES", liabilities), g);
        g.gridx = 3;
        g.weightx = 0;
        eq.add(operator("+"), g);
        g.gridx = 4;
        g.weightx = 1;
        eq.add(equationCard("OWNER'S EQUITY", equity), g);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        content.add(eq, c);

        equation.setFont(Theme.font(Font.BOLD, 13));
        c.gridy = 1;
        c.insets = new Insets(10, 2, 18, 0);
        content.add(equation, c);

        // recent entries (left) and six figures (right)
        Theme.Card recentCard = new Theme.Card();
        recentCard.setLayout(new BorderLayout(0, 10));
        recentCard.add(Theme.label("Recent entries", Font.BOLD, 15, Theme.INK), BorderLayout.NORTH);
        JTable table = recent.table(false);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Theme.LINE));
        sp.getViewport().setBackground(Color.WHITE);
        sp.setPreferredSize(new Dimension(300, 300));
        recentCard.add(sp, BorderLayout.CENTER);

        JPanel tiles = new JPanel(new GridLayout(3, 2, 12, 12));
        tiles.setOpaque(false);
        tiles.add(tile("TOTAL ASSETS", tAssets, "What the business owns"));
        tiles.add(tile("TOTAL LIABILITIES", tLiabilities, "What the business owes"));
        tiles.add(tile("TOTAL REVENUE", tRevenue, "Money earned"));
        tiles.add(tile("TOTAL EXPENSES", tExpenses, "Money spent"));
        tiles.add(tile("NET INCOME", tNet, "Revenue minus expenses"));
        tiles.add(tile("POSTED ENTRIES", tCount, "Journal entries recorded"));

        GridBagConstraints lower = new GridBagConstraints();
        lower.gridy = 2;
        lower.fill = GridBagConstraints.BOTH;
        lower.weighty = 1;
        lower.gridx = 0;
        lower.weightx = 1.2;
        lower.insets = new Insets(0, 0, 0, 16);
        content.add(recentCard, lower);
        lower.gridx = 1;
        lower.weightx = 1;
        lower.insets = new Insets(0, 0, 0, 0);
        content.add(tiles, lower);

        setContent(content, true);
    }

    private static JLabel value() {
        return Theme.label("", Font.BOLD, 26, Theme.INK);
    }

    private static JPanel equationCard(String caption, JLabel value) {
        Theme.Card card = new Theme.Card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel cap = Theme.label(caption, Font.BOLD, 11, Theme.MUTED);
        cap.setAlignmentX(LEFT_ALIGNMENT);
        value.setAlignmentX(LEFT_ALIGNMENT);
        card.add(cap);
        card.add(javax.swing.Box.createVerticalStrut(6));
        card.add(value);
        return card;
    }

    private static JLabel operator(String s) {
        JLabel l = Theme.label(s, Font.BOLD, 24, Theme.GOLD);
        l.setHorizontalAlignment(SwingConstants.CENTER);
        l.setPreferredSize(new Dimension(46, 40));
        return l;
    }

    private static JPanel tile(String caption, JLabel value, String hint) {
        Theme.Card card = new Theme.Card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel cap = Theme.label(caption, Font.BOLD, 11, Theme.MUTED);
        JLabel h = Theme.label(hint, Font.PLAIN, 12, Theme.MUTED);
        cap.setAlignmentX(LEFT_ALIGNMENT);
        value.setAlignmentX(LEFT_ALIGNMENT);
        h.setAlignmentX(LEFT_ALIGNMENT);
        value.setFont(Theme.font(Font.BOLD, 22));
        card.add(cap);
        card.add(javax.swing.Box.createVerticalStrut(4));
        card.add(value);
        card.add(javax.swing.Box.createVerticalStrut(2));
        card.add(h);
        return card;
    }

    private void guarded(Runnable r) {
        try {
            r.run();
        } catch (DbException e) {
            Theme.error(this, e);
        }
    }

    private void resetData() {
        int answer = JOptionPane.showConfirmDialog(this,
                "This deletes every posted entry, including adjustments.\nThe chart of accounts is kept.\n\nContinue?",
                "Reset data", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (answer == JOptionPane.OK_OPTION) {
            Repo.deleteAll();
            refresh();
        }
    }

    @Override
    public void refresh() {
        List<Account> accounts = Repo.accounts();
        List<Entry> entries = Repo.entries();
        Accounting.Totals t = Accounting.totals(accounts, entries);

        assets.setText(Fmt.peso(t.assets()));
        liabilities.setText(Fmt.peso(t.liabilities()));
        equity.setText(Fmt.peso(t.equity()));
        if (t.balanced()) {
            equation.setText("Accounting equation balanced ✓");
            equation.setForeground(Theme.GREEN);
        } else {
            equation.setText("Out of balance by " + Fmt.peso(t.difference().abs()));
            equation.setForeground(Theme.RED);
        }

        tAssets.setText(Fmt.peso(t.assets()));
        tLiabilities.setText(Fmt.peso(t.liabilities()));
        tRevenue.setText(Fmt.peso(t.revenue()));
        tExpenses.setText(Fmt.peso(t.expenses()));
        tNet.setText(Fmt.peso(t.netIncome()));
        tNet.setForeground(t.netIncome().signum() > 0 ? Theme.GREEN : t.netIncome().signum() < 0 ? Theme.RED : Theme.INK);
        tCount.setText(String.valueOf(t.entries()));

        recent.clear();
        List<Entry> latest = new ArrayList<>(entries);
        java.util.Collections.reverse(latest);
        if (latest.isEmpty()) {
            recent.add(Grid.NOTE, "No entries yet.");
        }
        for (Entry e : latest.stream().limit(8).toList()) {
            recent.add(Grid.NORMAL, Fmt.longDate(e.date()), e.reference(), e.description(), Fmt.peso(e.amount()));
        }
        recent.done();
    }
}
