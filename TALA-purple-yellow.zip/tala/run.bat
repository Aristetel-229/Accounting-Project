@echo off
rem Starts TALA. Put the mysql-connector-j .jar in the "lib" folder first.
rem   run.bat           normal start (MySQL)
rem   run.bat --demo    sample data in memory, no MySQL needed
cd /d "%~dp0"
if not exist out call build.bat
java -cp "out;lib/*" tala.Main %*
