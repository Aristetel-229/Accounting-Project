# TALA - Student Edition

A small double-entry accounting app. **Java (Swing)** for the program, **MySQL** for the data.

Screens: Dashboard, Journal Entry, General Journal, Chart of Accounts, General Ledger and 12 Columnar (worksheet).

## What you need

1. **JDK 17 or newer** (`java -version` and `javac -version` should both work).
2. **MySQL 8** (or MariaDB 10.5+) running on your computer, and a user that may create a database
   (the default `root` works).
3. **MySQL Connector/J**, the JDBC driver. Download the *Platform Independent* archive from
   <https://dev.mysql.com/downloads/connector/j/>, unpack it, and copy `mysql-connector-j-<version>.jar`
   into the `lib` folder of this project.

## Run it

| | Windows | macOS / Linux |
|---|---|---|
| Compile | `build.bat` | `./build.sh` |
| Start | `run.bat` | `./run.sh` |
| Try it without MySQL (sample data, nothing saved) | `run.bat --demo` | `./run.sh --demo` |
| Run the accounting self-tests | | `./test.sh` |

On the first start TALA connects to MySQL with the saved settings. If that fails, a dialog asks for
host, port, database name, user and password. Once it connects it **creates the database (`tala`), the
tables and the chart of accounts for you**, and remembers the settings in `tala.properties`
(the password is stored there as plain text, so don't share that file).

If the connection drops later, the green "Connected to MySQL" badge in the top bar turns red. Click it to
change the settings and reconnect.

**Using an IDE (NetBeans, IntelliJ, Eclipse):** open the folder as a Maven project (`pom.xml`).
The driver is downloaded automatically and `lib` is not needed. The main class is `tala.Main` (the code is in the `ui`, `logic` and `data` folders).

**Prefer to create the database by hand?** Run `schema.sql` in MySQL Workbench. It is the same thing
the app does by itself.

## Using it

- **Journal Entry** - pick the date (`YYYYMMDD`), amount, description, the account to debit and the account
  to credit. The preview line and the message under it show whether the entry can be posted.
  Every entry debits one account and credits another for the same amount, so the books always balance.
  Select a row in *Posted entries* and press *Delete Selected Entry* to remove just that one.
- **General Journal** - all entries in date order with particulars, post reference (account code), debit and credit.
- **Chart of Accounts** - the accounts you can use, with type and normal balance.
- **General Ledger** - one ledger per account you have used, with running balance and ending balance.
  A balance on the opposite side of the account's normal balance is flagged *Abnormal balance*.
- **12 Columnar** - unadjusted trial balance, adjustments, adjusted trial balance, income statement,
  owner's equity and balance sheet. The Balance Sheet columns of the GRAND TOTAL row end in `0.00` when debit equals credit
  (if they do not match, the real difference is shown instead). *Add Adjustment* posts an adjusting entry (reference starts with `AJ`);
  *Download CSV* saves the worksheet for Excel.
- **Dashboard** - assets = liabilities + owner's equity, totals, net income and the latest entries.
  *Reset Data* deletes all entries (the chart of accounts stays).

### How the numbers are worked out

- Adjusting entries are normal posted entries marked as adjustments. They show up in the Journal, Ledger and
  Dashboard like any other entry, and the 12 Columnar separates them into its Adjustments columns.
- Dashboard owner's equity = equity accounts (capital less drawings) + net income, so the equation
  balances whenever the entries do.
- Asset accounts with a credit normal balance (Allowance for Doubtful Accounts, Accumulated Depreciation)
  reduce total assets.
- In the worksheet, net income (or loss) balances the Income Statement columns and moves into Owner's Equity;
  the ending equity then balances the Owner's Equity columns and moves into the Balance Sheet.

## Project layout (where is what?)

The code is sorted into folders so you always know where to look. **Start with `Main.java`, then follow the table.**

```
src/main/java/tala/
  Main.java                START HERE - starts the program

  ui/                      SCREENS - everything you see (purple + yellow design)
    MainFrame.java           the window and the top tabs
    Page.java                template shared by every screen
    Theme.java               ALL colours, fonts, buttons, cards (change the look here)
    Grid.java                the table style used everywhere
    DashboardPage.java       Dashboard
    JournalEntryPage.java    Journal Entry (+ EntryForm.java, the form itself)
    GeneralJournalPage.java  General Journal
    ChartPage.java           Chart of Accounts
    LedgerPage.java          General Ledger
    WorksheetPage.java       12 Columnar
    DbSettingsDialog.java    MySQL connection window

  logic/                   RULES - the accounting itself (no screens, no database)
    Accounting.java          all the math: totals, ledger balances, 12 columnar
    Account.java, Entry.java the two things the app stores
    Validate.java            checks the date and amount typed by the user
    Fmt.java                 number and date formatting (1,234.50 / Nov. 3)

  data/                    DATABASE - saving and loading
    Db.java                  connection settings, table SQL, starter accounts
    Repo.java                the one door the screens use to get data
    Store.java               list of what the data layer can do
    MySqlStore.java          real MySQL version
    MemoryStore.java         demo version (nothing saved)
    Status.java, DbException.java   connection badge and error type

src/test/java/tala/        AccountingCheck (self-tests), UiSnapshot (screenshots of every screen)
schema.sql                 the database as plain SQL
```

Every file starts with a small box that says **what the file does** and **who uses it**.

**How the screens, rules and data connect:** a screen (`ui`) asks `Repo` (`data`) for the accounts and entries,
hands them to `Accounting` (`logic`) to calculate, and shows the answer in a `Grid`.

**Want different colours?** Open `ui/Theme.java`. The purples (`PURPLE_DARK`, `PURPLE`, `PURPLE_LIGHT`) and yellows
(`GOLD`, `YELLOW`, `YELLOW_SOFT`) are at the top; every screen uses them.

Tables: `accounts (code, name, type, normal_balance, active)` and
`journal_entries (id, entry_date, reference, description, debit_code, credit_code, amount, is_adjustment)`.

## Limits worth knowing

- The chart of accounts is fixed to the starter list in `Db.java` (`SEED`). To add an account, add a row there
  (or `INSERT` it into the `accounts` table).
- One user, no login. Each entry has exactly one debit and one credit account.
- Amounts are `DECIMAL(15,2)`, so up to 9,999,999,999,999.99.

## Troubleshooting

| Message | Fix |
|---|---|
| *MySQL JDBC driver not found* | The connector `.jar` is missing from `lib` (see above). |
| *Communications link failure* / *Connection refused* | MySQL is not running, or host / port is wrong (default `localhost` / `3306`). |
| *Access denied for user* | Wrong user or password in the connection dialog. |
| *CREATE command denied* | The user may not create databases. Create an empty database in Workbench, then enter its name in the dialog. |
