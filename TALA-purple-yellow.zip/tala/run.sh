#!/usr/bin/env bash
# Starts TALA. Put the mysql-connector-j .jar in ./lib first.
#   ./run.sh           normal start (MySQL)
#   ./run.sh --demo    sample data in memory, no MySQL needed
cd "$(dirname "$0")"
if [ ! -d out ]; then ./build.sh; fi
exec java -cp "out:lib/*" tala.Main "$@"
